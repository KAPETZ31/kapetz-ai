package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChecklistItem
import com.example.ui.theme.*

@Composable
fun ChecklistScreen(
    isTagalog: Boolean,
    checklist: List<ChecklistItem>,
    onToggleItem: (String) -> Unit,
    onResetChecklist: () -> Unit
) {
    val completedCount = checklist.count { it.isCompleted }
    val progress = if (checklist.isNotEmpty()) completedCount.toFloat() / checklist.size else 0f

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isTagalog) "Talaan ng Pagpapakain at Pag-aalaga" else "Feeding & Maintenance Checklist",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = MetallicSilver
                        )
                    )
                    Text(
                        text = if (isTagalog) "Araw-araw at lingguhang pagsusuri sa kaligtasan" else "Daily & weekly husbandry compliance verification",
                        style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilverMuted)
                    )
                }

                IconButton(
                    onClick = onResetChecklist,
                    modifier = Modifier.testTag("reset_checklist_button")
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset", tint = ElectricBlue)
                }
            }
        }

        // Progress Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSilverSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isTagalog) "Natapos na Gawain" else "Tasks Completed",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MetallicSilver, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "$completedCount / ${checklist.size}",
                            style = MaterialTheme.typography.bodyMedium.copy(color = ElectricBlue, fontWeight = FontWeight.Black)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = ElectricBlue,
                        trackColor = SlateSurfaceElevated
                    )
                }
            }
        }

        // Checklist Items
        items(checklist) { item ->
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = DarkCharcoalSurface,
                border = BorderStroke(1.dp, if (item.isCompleted) ElectricBlue.copy(alpha = 0.6f) else BorderSilverSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleItem(item.id) }
                    .testTag("checklist_item_${item.id}")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Checkbox(
                        checked = item.isCompleted,
                        onCheckedChange = { onToggleItem(item.id) },
                        colors = CheckboxDefaults.colors(
                            checkedColor = ElectricBlue,
                            uncheckedColor = MetallicSilverMuted,
                            checkmarkColor = ObsidianBlack
                        )
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = SlateSurfaceElevated
                            ) {
                                Text(
                                    text = item.category,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = ElectricBlue,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isTagalog) item.taskTl else item.taskEn,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (item.isCompleted) MetallicSilverMuted else MetallicSilver,
                                fontWeight = if (item.isCompleted) FontWeight.Normal else FontWeight.SemiBold
                            )
                        )
                    }
                }
            }
        }
    }
}
