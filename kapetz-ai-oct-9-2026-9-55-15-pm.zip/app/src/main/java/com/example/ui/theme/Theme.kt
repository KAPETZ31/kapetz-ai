package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val KapetzDarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = ObsidianBlack,
    primaryContainer = ElectricBlueDark,
    onPrimaryContainer = ElectricBlueGlow,
    secondary = MetallicSilver,
    onSecondary = ObsidianBlack,
    secondaryContainer = SlateSurfaceElevated,
    onSecondaryContainer = MetallicSilver,
    tertiary = MoltIndicatorPurple,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = MetallicSilver,
    surface = DarkCharcoalSurface,
    onSurface = MetallicSilver,
    surfaceVariant = SlateSurfaceElevated,
    onSurfaceVariant = MetallicSilverMuted,
    outline = BorderSilverSubtle,
    error = VenomHazardRed,
    onError = PureWhite
)

@Composable
fun KapetzTheme(
    content: @Composable () -> Unit
) {
    // KAPETZ AI uses a branded dark black, silver, and electric-blue visual identity
    MaterialTheme(
        colorScheme = KapetzDarkColorScheme,
        typography = Typography,
        content = content
    )
}
