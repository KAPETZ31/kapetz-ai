package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// KAPETZ AI Palette: Dark Black, Silver, and Electric Blue
val ObsidianBlack = Color(0xFF090C12)
val DarkCharcoalSurface = Color(0xFF101520)
val SlateSurfaceElevated = Color(0xFF181F2E)
val BorderSilverSubtle = Color(0xFF2B3648)

val ElectricBlue = Color(0xFF00E5FF)
val ElectricBlueGlow = Color(0xFF38EFFF)
val ElectricBlueDark = Color(0xFF005866)
val DeepCobalt = Color(0xFF0A2540)

val MetallicSilver = Color(0xFFE2E8F0)
val MetallicSilverMuted = Color(0xFF94A3B8)
val PureWhite = Color(0xFFFFFFFF)

// Status & Warnings
val VenomHazardRed = Color(0xFFFF3366)
val VenomWarningOrange = Color(0xFFFF9100)
val VerifiedGreen = Color(0xFF00E676)
val MoltIndicatorPurple = Color(0xFFB388FF)
