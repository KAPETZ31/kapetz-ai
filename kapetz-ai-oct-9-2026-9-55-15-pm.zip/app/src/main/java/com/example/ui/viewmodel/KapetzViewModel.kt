package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GuidesAndChecklists
import com.example.data.SpeciesDatabase
import com.example.data.local.KapetzDatabase
import com.example.data.remote.GeminiService
import com.example.data.repository.PetRepository
import com.example.model.CareReminder
import com.example.model.ChatMessage
import com.example.model.ChecklistItem
import com.example.model.MessageSender
import com.example.model.Species
import com.example.model.SpeciesCategory
import com.example.model.UserPet
import com.example.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class AppScreen {
    object Home : AppScreen()
    object Library : AppScreen()
    data class SpeciesDetail(val speciesId: String) : AppScreen()
    object Compare : AppScreen()
    object MyPets : AppScreen()
    object SetupGuides : AppScreen()
    object Checklist : AppScreen()
    object AiChat : AppScreen()
    object Profile : AppScreen()
}

class KapetzViewModel(application: Application) : AndroidViewModel(application) {

    private val db = KapetzDatabase.getDatabase(application)
    private val repository = PetRepository(db.petDao(), db.profileDao())
    private val geminiService = GeminiService()

    // Navigation state
    private val _currentScreen = MutableStateFlow<AppScreen>(AppScreen.Home)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Language state (true = Tagalog/Filipino, false = English)
    private val _isTagalog = MutableStateFlow(false)
    val isTagalog: StateFlow<Boolean> = _isTagalog.asStateFlow()

    fun toggleLanguage() {
        _isTagalog.value = !_isTagalog.value
    }

    fun setLanguage(tagalog: Boolean) {
        _isTagalog.value = tagalog
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    // Species Library Search & Filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<SpeciesCategory?>(null)
    val selectedCategory: StateFlow<SpeciesCategory?> = _selectedCategory.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: SpeciesCategory?) {
        _selectedCategory.value = category
    }

    val filteredSpecies: StateFlow<List<Species>> = MutableStateFlow(SpeciesDatabase.allSpecies)

    fun getFilteredSpeciesList(): List<Species> {
        val q = _searchQuery.value
        val cat = _selectedCategory.value
        var list = if (q.isBlank()) SpeciesDatabase.allSpecies else SpeciesDatabase.search(q)
        if (cat != null) {
            list = list.filter { it.category == cat }
        }
        return list
    }

    // Comparison species selection
    private val _compareSpecies1 = MutableStateFlow(SpeciesDatabase.allSpecies[0])
    val compareSpecies1: StateFlow<Species> = _compareSpecies1.asStateFlow()

    private val _compareSpecies2 = MutableStateFlow(
        SpeciesDatabase.allSpecies.getOrNull(3) ?: SpeciesDatabase.allSpecies[1]
    )
    val compareSpecies2: StateFlow<Species> = _compareSpecies2.asStateFlow()

    fun setCompareSpecies1(species: Species) {
        _compareSpecies1.value = species
    }

    fun setCompareSpecies2(species: Species) {
        _compareSpecies2.value = species
    }

    // User Pets & Personalized Reminders
    val userPets: StateFlow<List<UserPet>> = repository.allPets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val careReminders: StateFlow<List<CareReminder>> = repository.personalizedReminders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userProfile: StateFlow<UserProfile?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun addPet(
        name: String,
        speciesId: String,
        customSpecies: String,
        category: String,
        acquisitionDate: String,
        stage: String,
        feedIntervalDays: Int,
        notes: String
    ) {
        viewModelScope.launch {
            val pet = UserPet(
                name = name,
                speciesId = speciesId,
                customSpeciesName = customSpecies,
                category = category,
                acquisitionDate = acquisitionDate,
                stage = stage,
                feedIntervalDays = feedIntervalDays,
                customNotes = notes
            )
            repository.addPet(pet)
        }
    }

    fun deletePet(pet: UserPet) {
        viewModelScope.launch {
            repository.deletePet(pet)
        }
    }

    fun logFeeding(pet: UserPet) {
        viewModelScope.launch {
            repository.logFeeding(pet)
        }
    }

    fun logMolting(pet: UserPet) {
        viewModelScope.launch {
            repository.logMolting(pet)
        }
    }

    fun saveProfile(username: String, email: String, experience: String, region: String) {
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfile()
            repository.saveProfile(
                current.copy(
                    username = username,
                    email = email,
                    experienceLevel = experience,
                    region = region
                )
            )
        }
    }

    // Husbandry Checklist state
    private val _checklist = MutableStateFlow(GuidesAndChecklists.defaultChecklist)
    val checklist: StateFlow<List<ChecklistItem>> = _checklist.asStateFlow()

    fun toggleChecklistItem(id: String) {
        _checklist.value = _checklist.value.map {
            if (it.id == id) it.copy(isCompleted = !it.isCompleted) else it
        }
    }

    fun resetChecklist() {
        _checklist.value = _checklist.value.map { it.copy(isCompleted = false) }
    }

    // AI Chat State
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = MessageSender.KAPETZ_AI,
                text = "Welcome to KAPETZ AI! I am your exotic pet care specialist. Ask me anything about tarantulas, scorpions, centipedes, and reptiles — from feeding schedules, humidity, and molting to enclosure setups. How can I assist you today?\n\n*Paalala: Maaari ka ring magtanong sa Tagalog! I-click ang wika sa itaas.*",
                references = listOf("KAPETZ Verified Husbandry Standards")
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    fun sendChatMessage(prompt: String) {
        if (prompt.isBlank() || _isChatLoading.value) return

        val userMsg = ChatMessage(
            sender = MessageSender.USER,
            text = prompt.trim()
        )
        _chatMessages.value = _chatMessages.value + userMsg
        _isChatLoading.value = true

        viewModelScope.launch {
            try {
                val registeredPetsSummary = userPets.value.joinToString(", ") { "${it.name} (${it.category})" }
                val (response, refs) = geminiService.askExoticAssistant(
                    userPrompt = prompt,
                    isTagalog = _isTagalog.value,
                    userPetsContext = registeredPetsSummary.ifEmpty { "No pets logged yet" }
                )
                val aiMsg = ChatMessage(
                    sender = MessageSender.KAPETZ_AI,
                    text = response,
                    references = refs
                )
                _chatMessages.value = _chatMessages.value + aiMsg
            } catch (e: Exception) {
                val errorMsg = ChatMessage(
                    sender = MessageSender.KAPETZ_AI,
                    text = if (_isTagalog.value) {
                        "Paumanhin, nagkaroon ng pansamantalang aberya sa koneksyon. Pakisubukan muli o tingnan ang verified species care sheets sa Aklatan."
                    } else {
                        "Apologies, a temporary connection error occurred. Please try again or reference our verified species library care sheets."
                    }
                )
                _chatMessages.value = _chatMessages.value + errorMsg
            } finally {
                _isChatLoading.value = false
            }
        }
    }

    // Pre-seed sample pet on first run if empty so user immediately experiences personalized reminders
    init {
        viewModelScope.launch {
            val existing = db.petDao().getAllPets()
            existing.collect { list ->
                if (list.isEmpty()) {
                    db.petDao().insertPet(
                        UserPet(
                            name = "Shadow",
                            speciesId = "scorpion_afs",
                            customSpeciesName = "Asian Forest Scorpion",
                            category = "SCORPIONS",
                            acquisitionDate = "2024-03-15",
                            stage = "Adult",
                            enclosureNotes = "5-gal glass vivarium, bioactive coco coir, flat cork hide",
                            lastFedDateMillis = System.currentTimeMillis() - (8 * 24 * 60 * 60 * 1000L), // 8 days ago
                            feedIntervalDays = 7,
                            lastMoltDateMillis = 0L,
                            customNotes = "Healthy male, active under UV blacklight"
                        )
                    )
                    db.profileDao().saveProfile(
                        UserProfile(
                            username = "KAPETZ Keeper",
                            email = "skorpsman31@gmail.com",
                            experienceLevel = "Intermediate",
                            preferredLanguage = "EN",
                            region = "Philippines"
                        )
                    )
                }
            }
        }
    }
}
