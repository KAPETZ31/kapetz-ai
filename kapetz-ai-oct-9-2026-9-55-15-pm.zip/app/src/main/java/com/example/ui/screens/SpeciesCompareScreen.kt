package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SpeciesDatabase
import com.example.model.Species
import com.example.ui.components.VenomBadge
import com.example.ui.theme.*

@Composable
fun SpeciesCompareScreen(
    isTagalog: Boolean,
    species1: Species,
    species2: Species,
    onSelectSpecies1: (Species) -> Unit,
    onSelectSpecies2: (Species) -> Unit
) {
    var expanded1 by remember { mutableStateOf(false) }
    var expanded2 by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        item {
            Text(
                text = if (isTagalog) "Paghambingin ang Dalawang Uri" else "Side-by-Side Species Comparison",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = MetallicSilver
                )
            )
            Text(
                text = if (isTagalog) "Suriin ang pagkakaiba sa laki, halumigmig, kamandag, at kulungan." else "Analyze differences in environmental parameters, venom potency, and temperament.",
                style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilverMuted)
            )
        }

        // Species Selectors Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Selector 1
                Box(modifier = Modifier.weight(1f)) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = DarkCharcoalSurface,
                        border = BorderStroke(1.dp, ElectricBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expanded1 = true }
                            .testTag("compare_selector_1")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isTagalog) species1.commonNameTl else species1.commonName,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MetallicSilver
                                    ),
                                    maxLines = 1
                                )
                                Text(
                                    text = species1.scientificName,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontStyle = FontStyle.Italic,
                                        color = ElectricBlue
                                    ),
                                    maxLines = 1
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = ElectricBlue
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = expanded1,
                        onDismissRequest = { expanded1 = false },
                        modifier = Modifier.background(DarkCharcoalSurface)
                    ) {
                        SpeciesDatabase.allSpecies.forEach { sp ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${sp.commonName} (${sp.scientificName})",
                                        color = MetallicSilver,
                                        fontSize = 12.sp
                                    )
                                },
                                onClick = {
                                    onSelectSpecies1(sp)
                                    expanded1 = false
                                }
                            )
                        }
                    }
                }

                // Selector 2
                Box(modifier = Modifier.weight(1f)) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = DarkCharcoalSurface,
                        border = BorderStroke(1.dp, BorderSilverSubtle),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expanded2 = true }
                            .testTag("compare_selector_2")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isTagalog) species2.commonNameTl else species2.commonName,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MetallicSilver
                                    ),
                                    maxLines = 1
                                )
                                Text(
                                    text = species2.scientificName,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontStyle = FontStyle.Italic,
                                        color = MetallicSilverMuted
                                    ),
                                    maxLines = 1
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = MetallicSilverMuted
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = expanded2,
                        onDismissRequest = { expanded2 = false },
                        modifier = Modifier.background(DarkCharcoalSurface)
                    ) {
                        SpeciesDatabase.allSpecies.forEach { sp ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${sp.commonName} (${sp.scientificName})",
                                        color = MetallicSilver,
                                        fontSize = 12.sp
                                    )
                                },
                                onClick = {
                                    onSelectSpecies2(sp)
                                    expanded2 = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Comparison Rows
        item {
            ComparisonRow(
                attribute = if (isTagalog) "Kamandag (Venom)" else "Venom Significance",
                val1 = { VenomBadge(species1.venomLevel, isTagalog) },
                val2 = { VenomBadge(species2.venomLevel, isTagalog) }
            )
        }

        item {
            ComparisonRow(
                attribute = if (isTagalog) "Laki ng Alaga (Adult Size)" else "Adult Size",
                val1 = { Text(species1.adultSize, color = MetallicSilver, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                val2 = { Text(species2.adultSize, color = MetallicSilver, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
            )
        }

        item {
            ComparisonRow(
                attribute = if (isTagalog) "Temperatura (Temp)" else "Temperature Range",
                val1 = { Text(species1.temperatureRange, color = ElectricBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                val2 = { Text(species2.temperatureRange, color = ElectricBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
        }

        item {
            ComparisonRow(
                attribute = if (isTagalog) "Halumigmig (Humidity)" else "Humidity Range",
                val1 = { Text(species1.humidityRange, color = MetallicSilver, fontSize = 12.sp) },
                val2 = { Text(species2.humidityRange, color = MetallicSilver, fontSize = 12.sp) }
            )
        }

        item {
            ComparisonRow(
                attribute = if (isTagalog) "Haba ng Buhay" else "Lifespan",
                val1 = { Text(if (isTagalog) species1.lifespanTl else species1.lifespan, color = MetallicSilver, fontSize = 12.sp) },
                val2 = { Text(if (isTagalog) species2.lifespanTl else species2.lifespan, color = MetallicSilver, fontSize = 12.sp) }
            )
        }

        item {
            ComparisonRow(
                attribute = if (isTagalog) "Ugali at Kilos" else "Temperament",
                val1 = { Text(if (isTagalog) species1.temperament.labelTl else species1.temperament.labelEn, color = MetallicSilver, fontSize = 12.sp) },
                val2 = { Text(if (isTagalog) species2.temperament.labelTl else species2.temperament.labelEn, color = MetallicSilver, fontSize = 12.sp) }
            )
        }

        item {
            ComparisonRow(
                attribute = if (isTagalog) "Paghawak sa Kamay" else "Handling Suitability",
                val1 = {
                    Text(
                        text = if (species1.handlingRecommended) (if (isTagalog) "Puwede (Gentle)" else "Tolerates Handling") else (if (isTagalog) "Bawal (Display only)" else "NO - Strictly Display"),
                        color = if (species1.handlingRecommended) VerifiedGreen else VenomHazardRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                val2 = {
                    Text(
                        text = if (species2.handlingRecommended) (if (isTagalog) "Puwede (Gentle)" else "Tolerates Handling") else (if (isTagalog) "Bawal (Display only)" else "NO - Strictly Display"),
                        color = if (species2.handlingRecommended) VerifiedGreen else VenomHazardRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            )
        }
    }
}

@Composable
fun ComparisonRow(
    attribute: String,
    val1: @Composable () -> Unit,
    val2: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderSilverSubtle, RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = attribute,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = MetallicSilverMuted,
                    fontWeight = FontWeight.Bold
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    val1()
                }
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(30.dp)
                        .background(BorderSilverSubtle)
                )
                Box(modifier = Modifier.weight(1f)) {
                    val2()
                }
            }
        }
    }
}
