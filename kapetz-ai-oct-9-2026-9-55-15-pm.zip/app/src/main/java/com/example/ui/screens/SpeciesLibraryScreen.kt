package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Species
import com.example.model.SpeciesCategory
import com.example.ui.components.VenomBadge
import com.example.ui.theme.*

@Composable
fun SpeciesLibraryScreen(
    isTagalog: Boolean,
    speciesList: List<Species>,
    searchQuery: String,
    selectedCategory: SpeciesCategory?,
    onSearchChange: (String) -> Unit,
    onCategorySelect: (SpeciesCategory?) -> Unit,
    onSpeciesClick: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = {
                Text(
                    text = if (isTagalog) "Maghanap ng uri (hal. Redknee, Forest Scorpion)..." else "Search species (e.g. Redknee, Forest Scorpion)...",
                    color = MetallicSilverMuted,
                    fontSize = 13.sp
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = ElectricBlue
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear",
                            tint = MetallicSilverMuted
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = DarkCharcoalSurface,
                unfocusedContainerColor = DarkCharcoalSurface,
                focusedBorderColor = ElectricBlue,
                unfocusedBorderColor = BorderSilverSubtle,
                focusedTextColor = MetallicSilver,
                unfocusedTextColor = MetallicSilver
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("species_search_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Category Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { onCategorySelect(null) },
                    label = { Text(if (isTagalog) "Lahat" else "All Species") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ElectricBlue,
                        selectedLabelColor = ObsidianBlack,
                        containerColor = DarkCharcoalSurface,
                        labelColor = MetallicSilver
                    ),
                    border = BorderStroke(1.dp, if (selectedCategory == null) ElectricBlue else BorderSilverSubtle)
                )
            }
            items(SpeciesCategory.values()) { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { onCategorySelect(if (selectedCategory == cat) null else cat) },
                    label = { Text(if (isTagalog) cat.displayNameTl else cat.displayNameEn) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ElectricBlue,
                        selectedLabelColor = ObsidianBlack,
                        containerColor = DarkCharcoalSurface,
                        labelColor = MetallicSilver
                    ),
                    border = BorderStroke(1.dp, if (selectedCategory == cat) ElectricBlue else BorderSilverSubtle)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Result count & verification label
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isTagalog) "${speciesList.size} uri ang natagpuan" else "${speciesList.size} species documented",
                style = MaterialTheme.typography.labelSmall.copy(color = MetallicSilverMuted)
            )
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = VerifiedGreen.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, VerifiedGreen.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Verified",
                        tint = VerifiedGreen,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = if (isTagalog) "Husbandry Verified" else "Husbandry Verified",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = VerifiedGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Species List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(speciesList) { species ->
                SpeciesCard(
                    species = species,
                    isTagalog = isTagalog,
                    onClick = { onSpeciesClick(species.id) }
                )
            }
        }
    }
}

@Composable
fun SpeciesCard(
    species: Species,
    isTagalog: Boolean,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderSilverSubtle, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag("species_card_${species.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isTagalog) species.commonNameTl else species.commonName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MetallicSilver
                        )
                    )
                    Text(
                        text = species.scientificName,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontStyle = FontStyle.Italic,
                            color = ElectricBlue
                        )
                    )
                }
                VenomBadge(level = species.venomLevel, isTagalog = isTagalog)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Specs Row (Temp, Humidity, Adult Size)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SpecBadge(
                    icon = Icons.Default.Thermostat,
                    text = species.temperatureRange.substringBefore("(")
                )
                SpecBadge(
                    icon = Icons.Default.WaterDrop,
                    text = species.humidityRange.substringBefore("(")
                )
                SpecBadge(
                    icon = Icons.Default.Straighten,
                    text = species.adultSize.substringBefore("(")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Habitat / Enclosure snippet
            Text(
                text = if (isTagalog) species.enclosureTl else species.enclosure,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MetallicSilverMuted,
                    fontSize = 11.sp
                ),
                maxLines = 2
            )
        }
    }
}

@Composable
fun SpecBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = SlateSurfaceElevated
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ElectricBlue,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = text.trim(),
                style = MaterialTheme.typography.labelSmall.copy(
                    color = MetallicSilver,
                    fontSize = 10.sp
                )
            )
        }
    }
}
