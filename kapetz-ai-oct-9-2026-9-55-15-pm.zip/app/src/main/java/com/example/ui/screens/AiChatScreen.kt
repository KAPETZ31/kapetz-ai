package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ChatMessage
import com.example.model.MessageSender
import com.example.ui.components.VeterinaryNoticeCard
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AiChatScreen(
    isTagalog: Boolean,
    messages: List<ChatMessage>,
    isLoading: Boolean,
    onSendMessage: (String) -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val suggestionChips = if (isTagalog) {
        listOf(
            "Bakit nakatihaya ang aking tarantula?",
            "Asian Forest Scorpion: Gaano kadalas magpakain?",
            "Ligtas na kulungan para sa Alupihan",
            "Crested Gecko: Sobrang init sa kuwarto",
            "Emergency: Nakagat ako ng alaga"
        )
    } else {
        listOf(
            "Why is my tarantula lying on its back?",
            "Asian Forest Scorpion: Feeding & humidity",
            "Giant Centipede escape prevention setup",
            "Crested Gecko overheating danger limits",
            "Emergency: What to do if bitten/stung"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        // Chat messages list
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp)
        ) {
            // Veterinary disclaimer at top of chat
            item {
                VeterinaryNoticeCard(isTagalog = isTagalog)
            }

            items(messages) { msg ->
                ChatBubble(message = msg, isTagalog = isTagalog)
            }

            if (isLoading) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(start = 12.dp, top = 4.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = ElectricBlue,
                            strokeWidth = 2.dp
                        )
                        Text(
                            text = if (isTagalog) "Sumasangguni ang KAPETZ AI sa exotic husbandry standards..." else "KAPETZ AI is consulting verified husbandry standards...",
                            style = MaterialTheme.typography.labelSmall.copy(color = MetallicSilverMuted)
                        )
                    }
                }
            }
        }

        // Suggestion chips horizontal scroll
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(suggestionChips) { chip ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = DarkCharcoalSurface,
                    border = BorderStroke(1.dp, BorderSilverSubtle),
                    onClick = {
                        onSendMessage(chip)
                    }
                ) {
                    Text(
                        text = chip,
                        style = MaterialTheme.typography.labelSmall.copy(color = ElectricBlue),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Input Field & Send Button
        Surface(
            color = DarkCharcoalSurface,
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            text = if (isTagalog) "Magtanong tungkol sa alaga..." else "Ask about feeding, molting, habitat...",
                            color = MetallicSilverMuted,
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_chat_input_field"),
                    maxLines = 3,
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SlateSurfaceElevated,
                        unfocusedContainerColor = SlateSurfaceElevated,
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = BorderSilverSubtle,
                        focusedTextColor = MetallicSilver,
                        unfocusedTextColor = MetallicSilver
                    )
                )

                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            val textToSend = inputText
                            inputText = ""
                            onSendMessage(textToSend)
                        }
                    },
                    enabled = inputText.isNotBlank() && !isLoading,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (inputText.isNotBlank() && !isLoading) ElectricBlue else SlateSurfaceElevated)
                        .testTag("ai_chat_send_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = if (inputText.isNotBlank() && !isLoading) ObsidianBlack else MetallicSilverMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ChatBubble(
    message: ChatMessage,
    isTagalog: Boolean
) {
    val isUser = message.sender == MessageSender.USER

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            // KAPETZ Scorpion Logo Avatar
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .border(1.dp, ElectricBlue, CircleShape)
                    .background(ObsidianBlack),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_kapetz_logo),
                    contentDescription = "KAPETZ",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            modifier = Modifier.widthIn(max = 300.dp),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            Surface(
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                color = if (isUser) ElectricBlue else DarkCharcoalSurface,
                border = if (!isUser) BorderStroke(1.dp, BorderSilverSubtle) else null
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = if (isUser) ObsidianBlack else MetallicSilver,
                            lineHeight = 20.sp
                        )
                    )

                    // Reference citations if provided
                    if (!isUser && message.references.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isTagalog) "Mga Sanggunian:" else "Sources & References:",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = ElectricBlue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                        message.references.forEach { ref ->
                            Text(
                                text = "• $ref",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MetallicSilverMuted,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
