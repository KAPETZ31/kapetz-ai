package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SpeciesDatabase
import com.example.model.CareReminder
import com.example.model.SpeciesCategory
import com.example.model.UserPet
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

@Composable
fun MyPetsScreen(
    isTagalog: Boolean,
    pets: List<UserPet>,
    reminders: List<CareReminder>,
    onAddPet: (name: String, speciesId: String, customSpecies: String, category: String, acquisitionDate: String, stage: String, feedInterval: Int, notes: String) -> Unit,
    onDeletePet: (UserPet) -> Unit,
    onLogFeeding: (UserPet) -> Unit,
    onLogMolting: (UserPet) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        // Header & Add Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isTagalog) "Mga Alaga Ko (My Pets)" else "My Exotic Pets Registry",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = MetallicSilver
                        )
                    )
                    Text(
                        text = if (isTagalog) "Subaybayan ang pagpapakain, pagbabalat, at paalala" else "Track feeding schedules, molts, and personalized alerts",
                        style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilverMuted)
                    )
                }
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricBlue,
                        contentColor = ObsidianBlack
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("add_pet_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isTagalog) "Magdagdag" else "Add Pet", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Security & Privacy notice
        item {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = SlateSurfaceElevated,
                border = BorderStroke(1.dp, BorderSilverSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Privacy",
                        tint = VerifiedGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (isTagalog)
                            "Pribado at Ligtas: Ang talaan ng iyong mga alaga ay ligtas na nakaimbak lamang sa iyong device."
                        else
                            "Private & Secure: Your pet records and husbandry logs remain private and safely on-device.",
                        style = MaterialTheme.typography.labelSmall.copy(color = MetallicSilverMuted)
                    )
                }
            }
        }

        // Pet Cards
        if (pets.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkCharcoalSurface,
                    border = BorderStroke(1.dp, BorderSilverSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pets,
                            contentDescription = null,
                            tint = ElectricBlue,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (isTagalog) "Wala pang nakatalang alaga" else "No exotic pets added yet",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MetallicSilver
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isTagalog) "Pindutin ang 'Magdagdag' sa itaas para irehistro ang iyong alaga." else "Click 'Add Pet' above to register your tarantula, scorpion, centipede, or reptile.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilverMuted)
                        )
                    }
                }
            }
        } else {
            items(pets) { pet ->
                PetCard(
                    pet = pet,
                    isTagalog = isTagalog,
                    onLogFeeding = { onLogFeeding(pet) },
                    onLogMolting = { onLogMolting(pet) },
                    onDelete = { onDeletePet(pet) }
                )
            }
        }
    }

    if (showAddDialog) {
        AddPetDialog(
            isTagalog = isTagalog,
            onDismiss = { showAddDialog = false },
            onConfirm = { name, speciesId, customSpecies, category, acqDate, stage, feedInterval, notes ->
                onAddPet(name, speciesId, customSpecies, category, acqDate, stage, feedInterval, notes)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun PetCard(
    pet: UserPet,
    isTagalog: Boolean,
    onLogFeeding: () -> Unit,
    onLogMolting: () -> Unit,
    onDelete: () -> Unit
) {
    val species = SpeciesDatabase.getById(pet.speciesId)
    val speciesDisplayName = species?.commonName ?: pet.customSpeciesName.ifEmpty { pet.category }
    val now = System.currentTimeMillis()
    val daysSinceFeed = TimeUnit.MILLISECONDS.toDays(now - pet.lastFedDateMillis)

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderSilverSubtle, RoundedCornerShape(14.dp))
            .testTag("user_pet_card_${pet.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(SlateSurfaceElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (pet.category) {
                                "SCORPIONS" -> Icons.Default.Shield
                                "CENTIPEDES" -> Icons.Default.Bolt
                                "REPTILES" -> Icons.Default.Visibility
                                else -> Icons.Default.BugReport
                            },
                            contentDescription = pet.category,
                            tint = ElectricBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            text = pet.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MetallicSilver
                            )
                        )
                        Text(
                            text = speciesDisplayName,
                            style = MaterialTheme.typography.bodySmall.copy(color = ElectricBlue)
                        )
                    }
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("delete_pet_${pet.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete",
                        tint = MetallicSilverMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Details row: Stage, Acquisition Date, Feeding Interval
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = SlateSurfaceElevated,
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = if (isTagalog) "Yugto" else "Stage",
                            style = MaterialTheme.typography.labelSmall.copy(color = MetallicSilverMuted, fontSize = 10.sp)
                        )
                        Text(
                            text = pet.stage,
                            style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilver, fontWeight = FontWeight.Bold)
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = SlateSurfaceElevated,
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = if (isTagalog) "Nakuha noong" else "Acquired",
                            style = MaterialTheme.typography.labelSmall.copy(color = MetallicSilverMuted, fontSize = 10.sp)
                        )
                        Text(
                            text = pet.acquisitionDate.ifEmpty { "N/A" },
                            style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilver, fontWeight = FontWeight.Bold)
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = SlateSurfaceElevated,
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = if (isTagalog) "Huling Pakain" else "Last Fed",
                            style = MaterialTheme.typography.labelSmall.copy(color = MetallicSilverMuted, fontSize = 10.sp)
                        )
                        Text(
                            text = if (isTagalog) "$daysSinceFeed araw na" else "$daysSinceFeed d ago",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (daysSinceFeed >= pet.feedIntervalDays) VenomWarningOrange else VerifiedGreen,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }

            // Post molt resting alert if active
            if (pet.isPostMoltResting) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MoltIndicatorPurple.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, MoltIndicatorPurple.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MoltIndicatorPurple, modifier = Modifier.size(16.dp))
                        Text(
                            text = if (isTagalog) "Kakatapos magbalat! Huwag pakainin habang malambot ang pangil." else "Post-molt resting: Do not offer food until fangs harden!",
                            style = MaterialTheme.typography.labelSmall.copy(color = MoltIndicatorPurple, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }

            if (pet.customNotes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Notes: ${pet.customNotes}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilverMuted, fontSize = 11.sp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons: "Fed Today" & "Recorded Molt"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onLogFeeding,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, ElectricBlue),
                    modifier = Modifier.weight(1f).testTag("log_fed_${pet.id}")
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isTagalog) "Napakain Ngayon" else "Fed Today",
                        color = ElectricBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                OutlinedButton(
                    onClick = onLogMolting,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MoltIndicatorPurple),
                    modifier = Modifier.weight(1f).testTag("log_molt_${pet.id}")
                ) {
                    Icon(imageVector = Icons.Default.AutoMode, contentDescription = null, tint = MoltIndicatorPurple, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isTagalog) "Nagbalat" else "Logged Molt",
                        color = MoltIndicatorPurple,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPetDialog(
    isTagalog: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (name: String, speciesId: String, customSpecies: String, category: String, acquisitionDate: String, stage: String, feedInterval: Int, notes: String) -> Unit
) {
    var petName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(SpeciesCategory.TARANTULAS) }
    var selectedSpecies by remember { mutableStateOf(SpeciesDatabase.getByCategory(SpeciesCategory.TARANTULAS).firstOrNull()) }
    var customSpeciesName by remember { mutableStateOf("") }
    var stage by remember { mutableStateOf("Juvenile") }
    var acquisitionDate by remember {
        mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
    }
    var feedIntervalDays by remember { mutableStateOf("7") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkCharcoalSurface,
        title = {
            Text(
                text = if (isTagalog) "Magdagdag ng Exotic Pet" else "Register New Exotic Pet",
                fontWeight = FontWeight.Bold,
                color = MetallicSilver
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = petName,
                        onValueChange = { petName = it },
                        label = { Text(if (isTagalog) "Pangalan ng Alaga *" else "Pet Name *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("add_pet_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MetallicSilver,
                            unfocusedTextColor = MetallicSilver,
                            focusedBorderColor = ElectricBlue
                        )
                    )
                }

                item {
                    Text(
                        text = if (isTagalog) "Kategorya" else "Category",
                        style = MaterialTheme.typography.labelSmall.copy(color = MetallicSilverMuted)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        SpeciesCategory.values().forEach { cat ->
                            val isSelected = selectedCategory == cat
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) ElectricBlue else SlateSurfaceElevated,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        selectedCategory = cat
                                        selectedSpecies = SpeciesDatabase.getByCategory(cat).firstOrNull()
                                    }
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = cat.name.take(4),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isSelected) ObsidianBlack else MetallicSilver,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = if (isTagalog) "Pumili ng Uri mula sa Aklatan" else "Select Species from Library",
                        style = MaterialTheme.typography.labelSmall.copy(color = MetallicSilverMuted)
                    )
                    val speciesInCategory = SpeciesDatabase.getByCategory(selectedCategory)
                    speciesInCategory.forEach { sp ->
                        val isSelected = selectedSpecies?.id == sp.id
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSelected) SlateSurfaceElevated else DarkCharcoalSurface,
                            border = BorderStroke(1.dp, if (isSelected) ElectricBlue else BorderSilverSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clickable {
                                    selectedSpecies = sp
                                    customSpeciesName = ""
                                }
                        ) {
                            Text(
                                text = "${sp.commonName} (${sp.scientificName})",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = if (isSelected) ElectricBlue else MetallicSilver,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                ),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = customSpeciesName,
                        onValueChange = { customSpeciesName = it },
                        label = { Text(if (isTagalog) "O I-type ang Custom Species" else "Or Enter Custom Species") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MetallicSilver,
                            unfocusedTextColor = MetallicSilver,
                            focusedBorderColor = ElectricBlue
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = acquisitionDate,
                        onValueChange = { acquisitionDate = it },
                        label = { Text(if (isTagalog) "Petsa kung kailan nakuha (YYYY-MM-DD)" else "Acquisition Date (YYYY-MM-DD)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MetallicSilver,
                            unfocusedTextColor = MetallicSilver,
                            focusedBorderColor = ElectricBlue
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = feedIntervalDays,
                        onValueChange = { feedIntervalDays = it.filter { char -> char.isDigit() } },
                        label = { Text(if (isTagalog) "Pagitan ng Pagkain (Araw)" else "Feeding Interval (Days)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MetallicSilver,
                            unfocusedTextColor = MetallicSilver,
                            focusedBorderColor = ElectricBlue
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(if (isTagalog) "Mga Tala (Kulungan, Pagbili, atbp.)" else "Enclosure & Keeper Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MetallicSilver,
                            unfocusedTextColor = MetallicSilver,
                            focusedBorderColor = ElectricBlue
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (petName.isNotBlank()) {
                        val interval = feedIntervalDays.toIntOrNull() ?: 7
                        onConfirm(
                            petName.trim(),
                            selectedSpecies?.id ?: "",
                            customSpeciesName.trim(),
                            selectedCategory.name,
                            acquisitionDate.trim(),
                            stage,
                            interval,
                            notes.trim()
                        )
                    }
                },
                enabled = petName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = ObsidianBlack),
                modifier = Modifier.testTag("confirm_add_pet_button")
            ) {
                Text(if (isTagalog) "I-save" else "Save Pet", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isTagalog) "Kanselahin" else "Cancel", color = MetallicSilverMuted)
            }
        }
    )
}
