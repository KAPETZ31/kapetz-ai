package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.UserProfile
import com.example.ui.components.VeterinaryNoticeCard
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    isTagalog: Boolean,
    profile: UserProfile?,
    onSaveProfile: (username: String, email: String, experience: String, region: String) -> Unit,
    onToggleLanguage: () -> Unit
) {
    var username by remember(profile) { mutableStateOf(profile?.username ?: "KAPETZ Keeper") }
    var email by remember(profile) { mutableStateOf(profile?.email ?: "skorpsman31@gmail.com") }
    var experience by remember(profile) { mutableStateOf(profile?.experienceLevel ?: "Intermediate") }
    var region by remember(profile) { mutableStateOf(profile?.region ?: "Philippines") }
    var isEditing by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        // Profile Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSilverSubtle, RoundedCornerShape(16.dp))
                    .testTag("profile_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .border(2.dp, ElectricBlue, CircleShape)
                            .background(ObsidianBlack),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_kapetz_logo),
                            contentDescription = "KAPETZ Logo",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = username,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = MetallicSilver
                        )
                    )
                    Text(
                        text = email,
                        style = MaterialTheme.typography.bodySmall.copy(color = ElectricBlue)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SlateSurfaceElevated
                    ) {
                        Text(
                            text = if (isTagalog) "Antas: $experience" else "Level: $experience Keeper",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MetallicSilverMuted,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Edit Profile Form
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSilverSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isTagalog) "Impormasyon ng Account" else "Account & Profile Details",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MetallicSilver
                            )
                        )
                        TextButton(onClick = {
                            if (isEditing) {
                                onSaveProfile(username, email, experience, region)
                            }
                            isEditing = !isEditing
                        }) {
                            Text(
                                text = if (isEditing) (if (isTagalog) "I-save" else "Save") else (if (isTagalog) "I-edit" else "Edit"),
                                color = ElectricBlue,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (isEditing) {
                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text(if (isTagalog) "Pangalan" else "Username") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = MetallicSilver,
                                unfocusedTextColor = MetallicSilver,
                                focusedBorderColor = ElectricBlue
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = MetallicSilver,
                                unfocusedTextColor = MetallicSilver,
                                focusedBorderColor = ElectricBlue
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = region,
                            onValueChange = { region = it },
                            label = { Text(if (isTagalog) "Rehiyon / Lokasyon" else "Region / Location") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = MetallicSilver,
                                unfocusedTextColor = MetallicSilver,
                                focusedBorderColor = ElectricBlue
                            )
                        )
                    } else {
                        ProfileInfoRow(
                            label = if (isTagalog) "Pangalan" else "Username",
                            value = username
                        )
                        ProfileInfoRow(
                            label = "Email",
                            value = email
                        )
                        ProfileInfoRow(
                            label = if (isTagalog) "Lokasyon" else "Region",
                            value = region
                        )
                        ProfileInfoRow(
                            label = if (isTagalog) "Karanasan" else "Experience Level",
                            value = experience
                        )
                    }
                }
            }
        }

        // Responsible Keeper Safety Pledge
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, VerifiedGreen.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = VerifiedGreen)
                        Text(
                            text = if (isTagalog) "Panunumpa sa Responsableng Pag-aalaga" else "Responsible Exotic Keeper Pledge",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MetallicSilver
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isTagalog)
                            "1. Walang walang-saysay na paghawak sa kamay sa makamandag na uri.\n2. Laging may maayos na kandado at selyadong bentilasyon laban sa pagtakas.\n3. Pagsunod sa mga batas ng DENR at CITES sa Pilipinas.\n4. Pag-una sa kapakanan ng hayop kaysa sa libangan."
                        else
                            "1. Zero unnecessary physical handling of venomous & fragile invertebrates.\n2. Redundant escape-proof latching mechanisms maintained daily.\n3. Compliance with national wildlife laws and CITES regulations.\n4. Prioritizing physiological welfare over entertainment.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MetallicSilverMuted,
                            lineHeight = 18.sp
                        )
                    )
                }
            }
        }

        // Technical Guide: How to Preview, Test, Publish & Free Tiers
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSilverSubtle, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (isTagalog) "Gabay sa Pag-preview, Pagsubok at Pag-publish" else "How to Preview, Test, & Publish",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = ElectricBlue
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isTagalog)
                            "• Preview: Maaaring i-test sa Android streaming emulator sa browser o i-open ang shared web URL.\n• Libreng Tier: Ang on-device database at AI local expert engine ay 100% libre at walang bayad.\n• Gemini API: Libreng quota hanggang sa rate limit ng Google AI Studio. Walang babayaran sa karaniwang paggamit.\n• Pag-export: Gamitin ang Settings menu sa itaas upang mag-export bilang Android APK o ZIP package."
                        else
                            "• Preview: Test directly in the streaming Android emulator or open the shared responsive Web URL.\n• Free Tier Policy: On-device Room database, local expert fallback, and core husbandry sheets operate completely free.\n• Gemini AI Calls: Uses standard Google AI Studio free tier limits with zero required frontend billing.\n• Publish & Export: Export production APK/AAB or source ZIP via the AI Studio Settings menu anytime.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MetallicSilverMuted,
                            lineHeight = 18.sp
                        )
                    )
                }
            }
        }

        // Veterinary Notice Advisory
        item {
            VeterinaryNoticeCard(isTagalog = isTagalog)
        }
    }
}

@Composable
fun ProfileInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilverMuted))
        Text(text = value, style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilver, fontWeight = FontWeight.Bold))
    }
}
