package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GuidesAndChecklists
import com.example.model.SetupGuide
import com.example.ui.theme.*

@Composable
fun SetupGuidesScreen(
    isTagalog: Boolean
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        item {
            Text(
                text = if (isTagalog) "Mga Gabay sa Kulungan at Kagamitan" else "Equipment & Enclosure Setup Guides",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = MetallicSilver
                )
            )
            Text(
                text = if (isTagalog) "Hakbang-hakbang na gabay para sa ligtas at tamang tirahan ng exotic pets" else "Step-by-step verified construction guides for escapes prevention and microclimates",
                style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilverMuted)
            )
        }

        items(GuidesAndChecklists.guides) { guide ->
            GuideCard(guide = guide, isTagalog = isTagalog)
        }
    }
}

@Composable
fun GuideCard(
    guide: SetupGuide,
    isTagalog: Boolean
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderSilverSubtle, RoundedCornerShape(14.dp))
            .testTag("guide_card_${guide.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isTagalog) guide.titleTl else guide.titleEn,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MetallicSilver
                    ),
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = SlateSurfaceElevated
                ) {
                    Text(
                        text = if (isTagalog) guide.categoryTl else guide.categoryEn,
                        style = MaterialTheme.typography.labelSmall.copy(color = ElectricBlue),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isTagalog) guide.summaryTl else guide.summaryEn,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MetallicSilverMuted,
                    fontSize = 12.sp
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Equipment needed
            Text(
                text = if (isTagalog) "Kailangang Kagamitan:" else "Required Equipment:",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = ElectricBlue
                )
            )
            val equipList = if (isTagalog) guide.equipmentRequiredTl else guide.equipmentRequiredEn
            equipList.forEach { eq ->
                Row(
                    modifier = Modifier.padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Build, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(12.dp))
                    Text(text = eq, style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilver))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Step by step
            Text(
                text = if (isTagalog) "Mga Hakbang sa Pagbuo:" else "Setup Instructions:",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MetallicSilver
                )
            )
            val stepsList = if (isTagalog) guide.stepsTl else guide.stepsEn
            stepsList.forEachIndexed { idx, step ->
                Row(
                    modifier = Modifier.padding(vertical = 3.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "${idx + 1}.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = ElectricBlue,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = step,
                        style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilver, lineHeight = 18.sp)
                    )
                }
            }

            // Safety tips
            Spacer(modifier = Modifier.height(10.dp))
            val tips = if (isTagalog) guide.safetyTipsTl else guide.safetyTipsEn
            tips.forEach { tip ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = VenomWarningOrange.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, VenomWarningOrange.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = VenomWarningOrange, modifier = Modifier.size(16.dp))
                        Text(
                            text = tip,
                            style = MaterialTheme.typography.bodySmall.copy(color = VenomWarningOrange, fontSize = 11.sp)
                        )
                    }
                }
            }
        }
    }
}
