package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.SpeciesDatabase
import com.example.model.CareReminder
import com.example.model.ReminderUrgency
import com.example.model.SpeciesCategory
import com.example.ui.components.VeterinaryNoticeCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen

@Composable
fun HomeScreen(
    isTagalog: Boolean,
    reminders: List<CareReminder>,
    onNavigate: (AppScreen) -> Unit,
    onSelectCategory: (SpeciesCategory) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        // Hero Card with Exotic Pets Terrarium Visual
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSilverSubtle, RoundedCornerShape(16.dp))
                    .testTag("home_hero_card")
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_kapetz_hero),
                            contentDescription = "Exotic Pet Terrarium Panorama",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            ObsidianBlack.copy(alpha = 0.85f),
                                            ObsidianBlack
                                        )
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, ElectricBlue, CircleShape)
                                    .background(ObsidianBlack)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_kapetz_logo),
                                    contentDescription = "KAPETZ Scorpion Logo",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            Column {
                                Text(
                                    text = "KAPETZ AI",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp,
                                        color = MetallicSilver
                                    )
                                )
                                Text(
                                    text = if (isTagalog)
                                        "Matalinong Gabay sa Pag-aalaga ng Exotic Pets"
                                    else
                                        "Scientific Exotic Pet Care & Husbandry",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = ElectricBlue
                                    )
                                )
                            }
                        }
                    }

                    // Quick AI consultation CTA
                    Surface(
                        color = SlateSurfaceElevated,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigate(AppScreen.AiChat) }
                            .testTag("home_ai_cta_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = "AI",
                                    tint = ElectricBlue,
                                    modifier = Modifier.size(24.dp)
                                )
                                Column {
                                    Text(
                                        text = if (isTagalog) "May Tanong Tungkol sa Alaga?" else "Have an Exotic Care Question?",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MetallicSilver
                                        )
                                    )
                                    Text(
                                        text = if (isTagalog) "Magtanong sa KAPETZ AI assistant" else "Ask KAPETZ AI for species-accurate advice",
                                        style = MaterialTheme.typography.labelSmall.copy(color = MetallicSilverMuted)
                                    )
                                }
                            }
                            FilledTonalButton(
                                onClick = { onNavigate(AppScreen.AiChat) },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = ElectricBlue,
                                    contentColor = ObsidianBlack
                                )
                            ) {
                                Text(
                                    text = if (isTagalog) "Magtanong" else "Chat Now",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Personalized Reminders Section
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isTagalog) "Mga Paalala sa Pag-aalaga" else "Personalized Care Reminders",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MetallicSilver
                        )
                    )
                    TextButton(onClick = { onNavigate(AppScreen.MyPets) }) {
                        Text(
                            text = if (isTagalog) "Tingnan Lahat" else "View Pets",
                            color = ElectricBlue
                        )
                    }
                }

                if (reminders.isEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkCharcoalSurface,
                        border = BorderStroke(1.dp, BorderSilverSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Up to date",
                                tint = VerifiedGreen,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isTagalog) "Lahat ng alaga ay maayos at napakain!" else "All pets are up-to-date with feedings!",
                                style = MaterialTheme.typography.bodyMedium.copy(color = MetallicSilver),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (isTagalog) "Magdagdag ng alaga sa Alaga Ko tab" else "Register more pets in My Pets to track routines",
                                style = MaterialTheme.typography.bodySmall.copy(color = MetallicSilverMuted)
                            )
                        }
                    }
                } else {
                    reminders.take(3).forEach { reminder ->
                        val cardBorderColor = when (reminder.urgency) {
                            ReminderUrgency.CRITICAL -> VenomHazardRed
                            ReminderUrgency.UPCOMING -> VenomWarningOrange
                            ReminderUrgency.INFO -> ElectricBlue
                        }

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, cardBorderColor.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(cardBorderColor.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = when (reminder.urgency) {
                                            ReminderUrgency.CRITICAL -> Icons.Default.Warning
                                            ReminderUrgency.UPCOMING -> Icons.Default.Fastfood
                                            ReminderUrgency.INFO -> Icons.Default.WaterDrop
                                        },
                                        contentDescription = null,
                                        tint = cardBorderColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "${reminder.petName} (${reminder.speciesName})",
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                color = ElectricBlue,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                        Text(
                                            text = if (isTagalog) reminder.dueTextTl else reminder.dueText,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = cardBorderColor,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (isTagalog) reminder.titleTl else reminder.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MetallicSilver
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (isTagalog) reminder.descriptionTl else reminder.description,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MetallicSilverMuted,
                                            fontSize = 12.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Species Categories Grid / Selector
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (isTagalog) "Mga Kategorya ng Uri" else "Species Categories",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MetallicSilver
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CategoryButton(
                        modifier = Modifier.weight(1f),
                        title = if (isTagalog) "Tarantulas" else "Tarantulas",
                        subtitle = "Theraphosidae",
                        icon = Icons.Default.BugReport,
                        onClick = {
                            onSelectCategory(SpeciesCategory.TARANTULAS)
                            onNavigate(AppScreen.Library)
                        }
                    )
                    CategoryButton(
                        modifier = Modifier.weight(1f),
                        title = if (isTagalog) "Alakdan" else "Scorpions",
                        subtitle = "Scorpiones",
                        icon = Icons.Default.Shield,
                        onClick = {
                            onSelectCategory(SpeciesCategory.SCORPIONS)
                            onNavigate(AppScreen.Library)
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CategoryButton(
                        modifier = Modifier.weight(1f),
                        title = if (isTagalog) "Alupihan" else "Centipedes",
                        subtitle = "Chilopoda",
                        icon = Icons.Default.Bolt,
                        onClick = {
                            onSelectCategory(SpeciesCategory.CENTIPEDES)
                            onNavigate(AppScreen.Library)
                        }
                    )
                    CategoryButton(
                        modifier = Modifier.weight(1f),
                        title = if (isTagalog) "Reptilya" else "Reptiles",
                        subtitle = "Squamata",
                        icon = Icons.Default.Visibility,
                        onClick = {
                            onSelectCategory(SpeciesCategory.REPTILES)
                            onNavigate(AppScreen.Library)
                        }
                    )
                }
            }
        }

        // Quick Feature Cards (Setup Guides, Daily Checklist, Species Comparison)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (isTagalog) "Mga Tool at Gabay sa Husbandry" else "Husbandry Tools & Guides",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MetallicSilver
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FeatureCard(
                        modifier = Modifier.weight(1f),
                        title = if (isTagalog) "Gabay sa Kulungan" else "Setup Guides",
                        desc = if (isTagalog) "Substrate, ventilation, latches" else "Substrate & ventilation",
                        icon = Icons.Default.HomeWork,
                        onClick = { onNavigate(AppScreen.SetupGuides) }
                    )
                    FeatureCard(
                        modifier = Modifier.weight(1f),
                        title = if (isTagalog) "Checklist" else "Checklist",
                        desc = if (isTagalog) "Araw-araw na gawain" else "Daily routine tasks",
                        icon = Icons.Default.Checklist,
                        onClick = { onNavigate(AppScreen.Checklist) }
                    )
                    FeatureCard(
                        modifier = Modifier.weight(1f),
                        title = if (isTagalog) "Paghambing" else "Compare",
                        desc = if (isTagalog) "Side-by-side specs" else "Side-by-side specs",
                        icon = Icons.Default.CompareArrows,
                        onClick = { onNavigate(AppScreen.Compare) }
                    )
                }
            }
        }

        // Veterinary Notice Advisory
        item {
            VeterinaryNoticeCard(isTagalog = isTagalog)
        }
    }
}

@Composable
fun CategoryButton(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(78.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = DarkCharcoalSurface,
        border = BorderStroke(1.dp, BorderSilverSubtle)
    ) {
        Row(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(SlateSurfaceElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = ElectricBlue,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MetallicSilver
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MetallicSilverMuted,
                        fontSize = 10.sp
                    )
                )
            }
        }
    }
}

@Composable
fun FeatureCard(
    modifier: Modifier = Modifier,
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(110.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = DarkCharcoalSurface,
        border = BorderStroke(1.dp, BorderSilverSubtle)
    ) {
        Column(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = ElectricBlue,
                modifier = Modifier.size(22.dp)
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MetallicSilver
                    ),
                    maxLines = 1
                )
                Text(
                    text = desc,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MetallicSilverMuted,
                        fontSize = 10.sp
                    ),
                    maxLines = 2
                )
            }
        }
    }
}
