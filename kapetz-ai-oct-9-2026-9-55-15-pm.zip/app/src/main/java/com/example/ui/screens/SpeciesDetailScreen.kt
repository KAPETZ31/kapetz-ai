package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Species
import com.example.ui.components.VenomBadge
import com.example.ui.components.VeterinaryNoticeCard
import com.example.ui.theme.*

@Composable
fun SpeciesDetailScreen(
    species: Species,
    isTagalog: Boolean,
    onBack: () -> Unit,
    onAskAboutSpecies: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        // Header Section
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSilverSubtle, RoundedCornerShape(16.dp))
                    .testTag("species_detail_header")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isTagalog) species.commonNameTl else species.commonName,
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = MetallicSilver
                                )
                            )
                            Text(
                                text = species.scientificName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontStyle = FontStyle.Italic,
                                    color = ElectricBlue
                                )
                            )
                        }
                        VenomBadge(level = species.venomLevel, isTagalog = isTagalog)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Temperament & Handling safety warning
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (species.handlingRecommended) SlateSurfaceElevated else VenomHazardRed.copy(alpha = 0.12f),
                        border = BorderStroke(
                            1.dp,
                            if (species.handlingRecommended) BorderSilverSubtle else VenomHazardRed.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (species.handlingRecommended) Icons.Default.Info else Icons.Default.PanTool,
                                contentDescription = null,
                                tint = if (species.handlingRecommended) ElectricBlue else VenomHazardRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = if (!species.handlingRecommended)
                                    (if (isTagalog) "BABALA: Bawal hawakan sa kamay (Display only / No handling)." else "SAFETY WARNING: Display animal only. Physical handling is strictly discouraged.")
                                else
                                    (if (isTagalog) "Maaring hawakan nang banayad at maingat." else "Docile; gentle handling permitted under supervision."),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (species.handlingRecommended) MetallicSilver else VenomHazardRed
                                )
                            )
                        }
                    }

                    if (species.warningNotes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isTagalog) "⚠️ ${species.warningNotesTl}" else "⚠️ ${species.warningNotes}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = VenomWarningOrange,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }
        }

        // Quick Stats Grid (Size, Lifespan, Temp, Humidity)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = if (isTagalog) "Laki" else "Adult Size",
                    value = species.adultSize,
                    icon = Icons.Default.Straighten
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = if (isTagalog) "Buhay" else "Lifespan",
                    value = if (isTagalog) species.lifespanTl else species.lifespan,
                    icon = Icons.Default.HourglassTop
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = if (isTagalog) "Temperatura" else "Temperature",
                    value = species.temperatureRange,
                    icon = Icons.Default.Thermostat
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = if (isTagalog) "Halumigmig" else "Humidity",
                    value = species.humidityRange,
                    icon = Icons.Default.WaterDrop
                )
            }
        }

        // Section 1: Natural Habitat & Geographic Distribution
        item {
            CareSection(
                title = if (isTagalog) "Natural na Tirahan at Pinagmulan" else "Natural Habitat & Distribution",
                icon = Icons.Default.Public,
                content = if (isTagalog) species.naturalHabitatTl else species.naturalHabitat
            )
        }

        // Section 2: Enclosure, Substrate & Ventilation
        item {
            CareSection(
                title = if (isTagalog) "Kulungan, Lupa at Bentilasyon" else "Enclosure, Substrate & Ventilation",
                icon = Icons.Default.HomeWork,
                bulletPoints = listOf(
                    (if (isTagalog) "Kulungan: " else "Enclosure: ") + (if (isTagalog) species.enclosureTl else species.enclosure),
                    (if (isTagalog) "Lupa (Substrate): " else "Substrate: ") + (if (isTagalog) species.substrateTl else species.substrate),
                    (if (isTagalog) "Bentilasyon: " else "Ventilation: ") + (if (isTagalog) species.ventilationTl else species.ventilation)
                )
            )
        }

        // Section 3: Hydration & Drinking Setup
        item {
            CareSection(
                title = if (isTagalog) "Tubig at Hydration" else "Hydration & Water Setup",
                icon = Icons.Default.Water,
                content = if (isTagalog) species.hydrationTl else species.hydration
            )
        }

        // Section 4: Diet & Feeding Schedule
        item {
            CareSection(
                title = if (isTagalog) "Diyeta at Iskedyul ng Pagpapakain" else "Diet & Feeding Schedule",
                icon = Icons.Default.Fastfood,
                bulletPoints = listOf(
                    (if (isTagalog) "Pagkain: " else "Diet: ") + (if (isTagalog) species.dietTl else species.diet),
                    (if (isTagalog) "Iskedyul: " else "Feeding Schedule: ") + (if (isTagalog) species.feedingScheduleTl else species.feedingSchedule)
                )
            )
        }

        // Section 5: Behavior, Defense & Temperament
        item {
            CareSection(
                title = if (isTagalog) "Ugali at Depensa" else "Behavior & Temperament",
                icon = Icons.Default.Psychology,
                bulletPoints = listOf(
                    (if (isTagalog) "Kilos: " else "Behavioral Traits: ") + (if (isTagalog) species.behaviorTl else species.behavior),
                    (if (isTagalog) "Ugali: " else "Temperament: ") + (if (isTagalog) species.temperament.labelTl else species.temperament.labelEn)
                )
            )
        }

        // Section 6: Molting & Shedding Dynamics
        item {
            CareSection(
                title = if (isTagalog) "Pagbabalat at Pagluluno (Molting / Shedding)" else "Molting & Shedding Protocol",
                icon = Icons.Default.AutoMode,
                content = if (isTagalog) species.moltingInfoTl else species.moltingInfo
            )
        }

        // Section 7: Breeding Basics
        item {
            CareSection(
                title = if (isTagalog) "Pangangasiwa sa Pagpaparami" else "Breeding & Reproductive Notes",
                icon = Icons.Default.Favorite,
                content = if (isTagalog) species.breedingNotesTl else species.breedingNotes
            )
        }

        // Section 8: Common Husbandry Mistakes (Avoidance)
        item {
            CareSection(
                title = if (isTagalog) "Mga Karaniwang Pagkakamali sa Pag-aalaga" else "Common Husbandry Mistakes",
                icon = Icons.Default.ErrorOutline,
                bulletPoints = if (isTagalog) species.commonMistakesTl else species.commonMistakes,
                accentColor = VenomWarningOrange
            )
        }

        // Section 9: Sources, Literature References & Verification
        item {
            CareSection(
                title = if (isTagalog) "Mga Sanggunian at Beterinaryong Batayan" else "Scientific Sources & References",
                icon = Icons.Default.MenuBook,
                bulletPoints = species.sources,
                accentColor = VerifiedGreen
            )
        }

        // Ask AI Button for this species
        item {
            Button(
                onClick = { onAskAboutSpecies("Tell me more about caring for ${species.commonName} (${species.scientificName})") },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricBlue,
                    contentColor = ObsidianBlack
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("ask_ai_about_species_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Psychology,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isTagalog) "Magtanong sa KAPETZ AI tungkol dito" else "Ask KAPETZ AI about this species",
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Veterinary Disclaimer
        item {
            VeterinaryNoticeCard(isTagalog = isTagalog)
        }
    }
}

@Composable
fun StatCard(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = DarkCharcoalSurface,
        border = BorderStroke(1.dp, BorderSilverSubtle)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = ElectricBlue,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall.copy(color = MetallicSilverMuted)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MetallicSilver
                )
            )
        }
    }
}

@Composable
fun CareSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: String? = null,
    bulletPoints: List<String>? = null,
    accentColor: androidx.compose.ui.graphics.Color = ElectricBlue
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoalSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderSilverSubtle, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MetallicSilver
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (!content.isNullOrBlank()) {
                Text(
                    text = content,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MetallicSilver,
                        lineHeight = 20.sp
                    )
                )
            }

            if (!bulletPoints.isNullOrEmpty()) {
                bulletPoints.forEach { point ->
                    Row(
                        modifier = Modifier.padding(vertical = 3.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "•",
                            color = accentColor,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = point,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MetallicSilver,
                                lineHeight = 20.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
