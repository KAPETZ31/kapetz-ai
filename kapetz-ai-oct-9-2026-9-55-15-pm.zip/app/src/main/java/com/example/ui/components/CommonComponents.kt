package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.VenomLevel
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KapetzTopBar(
    currentScreen: AppScreen,
    isTagalog: Boolean,
    onToggleLanguage: () -> Unit,
    onNavigateProfile: () -> Unit,
    onBack: (() -> Unit)? = null
) {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Circular official KAPETZ scorpion logo
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, ElectricBlue, CircleShape)
                        .background(ObsidianBlack),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_kapetz_logo),
                        contentDescription = "KAPETZ Scorpion Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "KAPETZ",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp,
                                color = MetallicSilver
                            )
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "AI",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = ElectricBlue
                            )
                        )
                    }
                    Text(
                        text = if (isTagalog) "Exotic Pet Care Assistant" else "Exotic Pet Care Assistant",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MetallicSilverMuted,
                            fontSize = 10.sp
                        )
                    )
                }
            }
        },
        navigationIcon = {
            if (onBack != null) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("top_bar_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = MetallicSilver
                    )
                }
            }
        },
        actions = {
            // Language Switcher Badge (EN / TL)
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = SlateSurfaceElevated,
                border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.5f)),
                modifier = Modifier
                    .padding(end = 8.dp)
                    .clickable { onToggleLanguage() }
                    .testTag("language_switch_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Language",
                        tint = ElectricBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (isTagalog) "TL (Filipino)" else "EN (English)",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = ElectricBlue,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            // User Profile avatar button
            IconButton(
                onClick = onNavigateProfile,
                modifier = Modifier.testTag("profile_nav_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AccountCircle,
                    contentDescription = "Profile",
                    tint = MetallicSilver
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = DarkCharcoalSurface,
            titleContentColor = MetallicSilver
        )
    )
}

@Composable
fun KapetzBottomNavigationBar(
    currentScreen: AppScreen,
    isTagalog: Boolean,
    onNavigate: (AppScreen) -> Unit
) {
    NavigationBar(
        containerColor = DarkCharcoalSurface,
        tonalElevation = 8.dp
    ) {
        val items = listOf(
            Triple(AppScreen.Home, Icons.Default.Home, if (isTagalog) "Home" else "Home"),
            Triple(AppScreen.Library, Icons.Default.MenuBook, if (isTagalog) "Aklatan" else "Library"),
            Triple(AppScreen.MyPets, Icons.Default.Pets, if (isTagalog) "Alaga Ko" else "My Pets"),
            Triple(AppScreen.AiChat, Icons.Default.Psychology, if (isTagalog) "KAPETZ AI" else "AI Chat"),
            Triple(AppScreen.Checklist, Icons.Default.Checklist, if (isTagalog) "Gawain" else "Tasks"),
            Triple(AppScreen.Compare, Icons.Default.CompareArrows, if (isTagalog) "Paghambing" else "Compare")
        )

        items.forEach { (screen, icon, label) ->
            val isSelected = when (currentScreen) {
                is AppScreen.SpeciesDetail -> screen == AppScreen.Library
                else -> currentScreen.javaClass == screen.javaClass
            }

            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = ObsidianBlack,
                    selectedTextColor = ElectricBlue,
                    indicatorColor = ElectricBlue,
                    unselectedIconColor = MetallicSilverMuted,
                    unselectedTextColor = MetallicSilverMuted
                )
            )
        }
    }
}

@Composable
fun VeterinaryNoticeCard(isTagalog: Boolean) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(12.dp),
        color = DarkCharcoalSurface,
        border = BorderStroke(1.dp, BorderSilverSubtle)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.MedicalServices,
                contentDescription = "Veterinary Notice",
                tint = ElectricBlue,
                modifier = Modifier.size(22.dp)
            )
            Column {
                Text(
                    text = if (isTagalog) "Paalalang Beterinaryo at Medikal" else "Exotic Veterinary Advisory",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = ElectricBlue
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (isTagalog)
                        "Ang impormasyon dito ay gabay sa tamang husbandry at HINDI kapalit ng lisensyadong exotic veterinarian. Kung may sakit o injury, kumonsulta agad sa espesyalistang beterinaryo."
                    else
                        "KAPETZ AI guidance reflects verified captive husbandry protocols and is NOT a substitute for licensed veterinary diagnosis. Seek an exotic veterinarian for medical emergencies.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MetallicSilverMuted,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}

@Composable
fun VenomBadge(level: VenomLevel, isTagalog: Boolean) {
    val (color, text) = when (level) {
        VenomLevel.MILD -> Pair(VerifiedGreen, if (isTagalog) "Mababang Kamandag" else "Mild Venom")
        VenomLevel.MODERATE -> Pair(VenomWarningOrange, if (isTagalog) "Masakit na Kagat" else "Moderate / Painful")
        VenomLevel.MEDICALLY_SIGNIFICANT -> Pair(VenomHazardRed, if (isTagalog) "Mataas na Kamandag" else "Medically Significant")
        VenomLevel.HAZARDOUS -> Pair(Color(0xFFFF0033), if (isTagalog) "LUBHANG DELIKADO" else "HAZARDOUS / DEADLY")
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.15f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Venom level",
                tint = color,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = color,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            )
        }
    }
}
