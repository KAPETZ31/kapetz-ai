package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_pets")
data class UserPet(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val speciesId: String,
    val customSpeciesName: String = "",
    val category: String, // TARANTULAS, SCORPIONS, CENTIPEDES, REPTILES
    val acquisitionDate: String, // e.g. "2024-05-10"
    val stage: String = "Juvenile", // Sling/Scorpling, Juvenile, Sub-adult, Adult
    val enclosureNotes: String = "",
    val lastFedDateMillis: Long = System.currentTimeMillis(),
    val feedIntervalDays: Int = 7,
    val lastMoltDateMillis: Long = 0L,
    val isPostMoltResting: Boolean = false,
    val customNotes: String = ""
)

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey
    val id: String = "primary_user",
    val username: String = "KAPETZ Keeper",
    val email: String = "skorpsman31@gmail.com",
    val experienceLevel: String = "Intermediate", // Beginner, Intermediate, Expert
    val preferredLanguage: String = "EN", // EN or TL
    val region: String = "Philippines",
    val joinedDate: Long = System.currentTimeMillis(),
    val isSafetyPledgeAccepted: Boolean = true
)

data class CareReminder(
    val id: String,
    val petId: Long,
    val petName: String,
    val speciesName: String,
    val title: String,
    val titleTl: String,
    val description: String,
    val descriptionTl: String,
    val urgency: ReminderUrgency,
    val isDue: Boolean,
    val dueText: String,
    val dueTextTl: String
)

enum class ReminderUrgency {
    CRITICAL,
    UPCOMING,
    INFO
}

data class ChecklistItem(
    val id: String,
    val taskEn: String,
    val taskTl: String,
    val category: String, // Daily, Weekly, Pre-Molt
    val isCompleted: Boolean = false
)
