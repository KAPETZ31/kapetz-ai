package com.example.model

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isWarning: Boolean = false,
    val references: List<String> = emptyList()
)

enum class MessageSender {
    USER,
    KAPETZ_AI
}

data class SetupGuide(
    val id: String,
    val titleEn: String,
    val titleTl: String,
    val categoryEn: String,
    val categoryTl: String,
    val summaryEn: String,
    val summaryTl: String,
    val stepsEn: List<String>,
    val stepsTl: List<String>,
    val equipmentRequiredEn: List<String>,
    val equipmentRequiredTl: List<String>,
    val safetyTipsEn: List<String>,
    val safetyTipsTl: List<String>
)
