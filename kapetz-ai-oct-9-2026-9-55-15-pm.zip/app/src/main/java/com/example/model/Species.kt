package com.example.model

enum class SpeciesCategory(val displayNameEn: String, val displayNameTl: String) {
    TARANTULAS("Tarantulas", "Mga Gagamba (Tarantula)"),
    SCORPIONS("Scorpions", "Mga Alakdan (Scorpion)"),
    CENTIPEDES("Centipedes", "Mga Alupihan (Centipede)"),
    REPTILES("Reptiles", "Mga Reptilya (Reptile)")
}

enum class VenomLevel(val labelEn: String, val labelTl: String, val severity: Int) {
    MILD("Mild / Low Medically Significant", "Mababang Kamandag / Hindi Kritikal", 1),
    MODERATE("Moderate / Painful Sting/Bite", "Katamtaman / Masakit na Kagat", 2),
    MEDICALLY_SIGNIFICANT("Medically Significant / Potent", "Mataas / Medically Significant", 3),
    HAZARDOUS("Hazardous / Strict Protocol Only", "Delikado / Mahigpit na Pag-iingat", 4)
}

enum class Temperament(val labelEn: String, val labelTl: String) {
    DOCILE("Docile & Calm", "Kalmado at Maamo"),
    NERVOUS("Nervous / Skittish", "Mabilis magulat / Matatakutin"),
    DEFENSIVE("Defensive & Fast", "Mabilis dumipensa at tumakbo"),
    AGGRESSIVE_STRIKER("Highly Defensive Striker", "Agresibong umaatake kapag naistorbo")
}

data class Species(
    val id: String,
    val commonName: String,
    val commonNameTl: String,
    val scientificName: String,
    val category: SpeciesCategory,
    val naturalHabitat: String,
    val naturalHabitatTl: String,
    val adultSize: String,
    val lifespan: String,
    val lifespanTl: String,
    val enclosure: String,
    val enclosureTl: String,
    val substrate: String,
    val substrateTl: String,
    val ventilation: String,
    val ventilationTl: String,
    val temperatureRange: String,
    val humidityRange: String,
    val hydration: String,
    val hydrationTl: String,
    val diet: String,
    val dietTl: String,
    val feedingSchedule: String,
    val feedingScheduleTl: String,
    val behavior: String,
    val behaviorTl: String,
    val moltingInfo: String,
    val moltingInfoTl: String,
    val breedingNotes: String,
    val breedingNotesTl: String,
    val commonMistakes: List<String>,
    val commonMistakesTl: List<String>,
    val sources: List<String>,
    val isVerified: Boolean = true,
    val warningNotes: String,
    val warningNotesTl: String,
    val venomLevel: VenomLevel,
    val temperament: Temperament,
    val handlingRecommended: Boolean = false
)
