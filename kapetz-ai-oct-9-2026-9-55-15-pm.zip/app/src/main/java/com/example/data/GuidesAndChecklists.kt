package com.example.data

import com.example.model.ChecklistItem
import com.example.model.SetupGuide

object GuidesAndChecklists {

    val guides: List<SetupGuide> = listOf(
        SetupGuide(
            id = "guide_terrestrial",
            titleEn = "Terrestrial Burrowing Arachnid Setup",
            titleTl = "Kulungan para sa Lupang Tarantula at Alakdan",
            categoryEn = "Tarantulas & Scorpions",
            categoryTl = "Gagamba at Alakdan",
            summaryEn = "Deep substrate, low falling height, and sturdy hide for ground-dwelling species.",
            summaryTl = "Malalim na lupa, mababang kisame upang hindi mahulog, at matibay na taguan.",
            stepsEn = listOf(
                "Clean the acrylic/glass enclosure with warm water (no chemical detergents).",
                "Add 10-15 cm of compacted coconut coir, peat moss, or topsoil mix to allow burrow stability.",
                "Ensure maximum height above substrate does not exceed 1.5x the animal's diagonal leg span.",
                "Bury a curved cork bark flat at a 45-degree angle to serve as a pre-started burrow starter.",
                "Place a shallow ceramic or plastic water dish flush with the substrate level.",
                "Verify cross-ventilation holes are clean and drilled on opposing side walls."
            ),
            stepsTl = listOf(
                "Linisin ang kulungan gamit ang malinis na maligamgam na tubig nang walang sabon.",
                "Maglagay ng 10-15 cm ng pinagsiksik na coco coir o lupa upang makapaghukay.",
                "Tiyaking ang taas mula sa lupa hanggang kisame ay hindi lalagpas sa 1.5x ng haba ng binti.",
                "Ibaon ang cork bark nang pahiwa bilang panimulang lungga.",
                "Maglagay ng mababaw na lalagyan ng tubig kapantay ng lupa.",
                "Suriin ang mga butas ng bentilasyon sa magkabilang gilid."
            ),
            equipmentRequiredEn = listOf(
                "Acrylic / Glass terrarium (30x30x20 cm)",
                "Coconut fiber or bioactive topsoil",
                "Natural cork bark round / flat",
                "Shallow water dish",
                "Substrate packer or tamper"
            ),
            equipmentRequiredTl = listOf(
                "Acrylic / Glass terrarium",
                "Coco coir o lupang pananim",
                "Cork bark para sa taguan",
                "Mababaw na mangkok ng tubig"
            ),
            safetyTipsEn = listOf(
                "Never leave excessive vertical drop height; a fall can rupture the tarantula's abdomen fatally.",
                "Never use sponges in the water dish; they collect harmful bacteria."
            ),
            safetyTipsTl = listOf(
                "Huwag gawing mataas ang kulungan; pwedeng pumutok ang tiyan kapag nahulog.",
                "Huwag maglagay ng espongha sa tubig; pinamumugaran ito ng bacteria."
            )
        ),
        SetupGuide(
            id = "guide_centipede",
            titleEn = "Escape-Proof Giant Centipede Enclosure",
            titleTl = "Ligtas at Hindi Matatakasang Kulungan ng Alupihan",
            categoryEn = "Centipedes",
            categoryTl = "Mga Alupihan",
            summaryEn = "Specialized airtight containment with escape prevention locks and micro-ventilation.",
            summaryTl = "Espesyal na selyadong kulungan na may kandado at micro-ventilation.",
            stepsEn = listOf(
                "Select a container taller than the centipede's full stretched body length.",
                "Verify latching mechanisms: Centipedes can push off decor with strong muscular leverage.",
                "Drill micro-ventilation holes strictly under 1.5mm in diameter (heated needle technique).",
                "Add 12-15 cm of damp organic substrate (coco coir mixed with sphagnum moss).",
                "Top with a generous layer of sterilized oak or magnolia leaf litter for natural foraging.",
                "Position heavy ceramic water bowl and multiple flat bark hides across the floor."
            ),
            stepsTl = listOf(
                "Pumili ng kulungan na mas mataas kaysa sa buong haba ng katawan ng alupihan.",
                "Tiyakin ang matibay na kandado sa takip; kayang itulak ng alupihan ang takip.",
                "Magbutas ng napakapinong bentilasyon (mas maliit sa 1.5mm).",
                "Maglagay ng 12-15 cm basang coco peat at sphagnum moss.",
                "Maglagay ng pinatuyong dahon para sa natural na tirahan.",
                "Maglagay ng mabigat na lalagyan ng tubig at mga taguan."
            ),
            equipmentRequiredEn = listOf(
                "Locking gasket enclosure (Lock & Lock or acrylic locking terrarium)",
                "Organic damp forest substrate",
                "Sterilized leaf litter & sphagnum moss",
                "Long feeding tongs (minimum 30 cm / 12 in)",
                "Heavy ceramic water dish"
            ),
            equipmentRequiredTl = listOf(
                "Kulungan na may mahigpit na lock/gasket",
                "Basang lupa at sphagnum moss",
                "Tuyong dahon para sa pagkukubli",
                "Mahabang sipit (tongs na 30 cm pataas)"
            ),
            safetyTipsEn = listOf(
                "ALWAYS inspect the lid seal before opening. Use 12-inch tongs during any maintenance.",
                "Never put your fingers near the opening even if the centipede appears hidden."
            ),
            safetyTipsTl = listOf(
                "Palaging gamitin ang mahabang sipit sa pag-aayos; huwag kailanman isusuksok ang kamay.",
                "Suriin muna ang takip bago buksan upang hindi biglang lumabas."
            )
        ),
        SetupGuide(
            id = "guide_arboreal",
            titleEn = "Tropical Arboreal Habitat (Gecko & Arboreal Spider)",
            titleTl = "Tropikal na Kulungang Puno (Gecko at Gagambang Puno)",
            categoryEn = "Reptiles & Tarantulas",
            categoryTl = "Reptilya at Gagamba",
            summaryEn = "Vertical orientation, dense foliage, climbing branches, and humidity dry-out cycles.",
            summaryTl = "Mataas na kulungan na may mga sanga, baging, at tamang ikot ng halumigmig.",
            stepsEn = listOf(
                "Select a vertically oriented terrarium (minimum 45x45x60 cm for geckos).",
                "Install a drainage layer (hydroton balls + mesh) beneath 8 cm of tropical bioactive substrate.",
                "Secure vertical cork bark tubes and sturdy branches diagonally across the enclosure.",
                "Add live or artificial plants to achieve 70% canopy cover for security and shade.",
                "Mount a magnetic feeding ledge and elevated water dish halfway up the wall.",
                "Install low-output UVB lighting and ensure mesh top permits fresh air exchange."
            ),
            stepsTl = listOf(
                "Pumili ng patayong terrarium (45x45x60 cm pataas).",
                "Maglagay ng drainage layer sa ilalim bago ang tropikal na lupa.",
                "Magkabit ng mga patayong sanga at cork bark na matatag.",
                "Maglagay ng mga halaman na sasakop sa 70% ng kulungan para sa taguan.",
                "Ikabit ang magnetic ledge para sa pagkain at tubig sa itaas na bahagi.",
                "Maglagay ng tamang ilaw na may UVB."
            ),
            equipmentRequiredEn = listOf(
                "Vertical screen-top terrarium",
                "Bioactive drainage clay balls & mesh",
                "Cork bark branch tubes",
                "Foliage & vines",
                "Elevated feeding ledge",
                "Digital thermo-hygrometer"
            ),
            equipmentRequiredTl = listOf(
                "Patayong terrarium na may screen sa itaas",
                "Mga sanga at cork bark para sa akyatan",
                "Mga halaman at baging",
                "Elevated food ledge at digital thermometer"
            ),
            safetyTipsEn = listOf(
                "Never exceed 28°C (82°F) for New Caledonian geckos to avoid fatal heat stroke.",
                "Allow humidity to drop to 50% during midday before evening misting to prevent respiratory infections."
            ),
            safetyTipsTl = listOf(
                "Huwag hayaang uminit nang higit sa 28°C upang hindi ma-heat stroke ang gecko.",
                "Hayaang matuyo ang halumigmig sa tanghali bago muling wisikan sa gabi."
            )
        )
    )

    val defaultChecklist: List<ChecklistItem> = listOf(
        ChecklistItem("c1", "Check and refill clean fresh water dishes", "Suriin at punuin ang malinis na tubig", "Daily"),
        ChecklistItem("c2", "Inspect temperature and humidity gauges", "Tingnan ang temperatura at humidity", "Daily"),
        ChecklistItem("c3", "Verify all enclosure latches and locks are securely fastened", "Siguraduhing nakakandado ang lahat ng kulungan", "Daily"),
        ChecklistItem("c4", "Spot clean bolus, uneaten prey items, and fecal deposits", "Alisin ang mga tira-tirang insekto at dumi", "Weekly"),
        ChecklistItem("c5", "Inspect specimens for signs of upcoming molt (dull coloration, bald spot darkens)", "Suriin kung magbabalat ang alaga (umiitim na balat)", "Weekly"),
        ChecklistItem("c6", "Conduct escape-drill & inspect integrity of mesh and silicone seams", "Suriin ang mga screen at gilid para walang lusutan", "Weekly"),
        ChecklistItem("c7", "Post-Molt check: Ensure fangs are hardened black before feeding", "Tiyaking itim at matigas na ang pangil bago magpakain", "Pre-Molt")
    )
}
