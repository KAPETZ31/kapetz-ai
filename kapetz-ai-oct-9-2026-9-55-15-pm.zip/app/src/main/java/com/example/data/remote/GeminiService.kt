package com.example.data.remote

import com.example.BuildConfig
import com.example.data.SpeciesDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun askExoticAssistant(
        userPrompt: String,
        isTagalog: Boolean,
        userPetsContext: String = ""
    ): Pair<String, List<String>> = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val response = callGeminiApi(apiKey, userPrompt, isTagalog, userPetsContext)
                if (response.isNotBlank()) {
                    val references = extractReferences(response)
                    return@withContext Pair(response, references)
                }
            } catch (e: Exception) {
                // Graceful fallback to offline exotic pet knowledge engine
            }
        }

        // Graceful verified local expert fallback
        return@withContext Pair(
            generateExpertFallbackAnswer(userPrompt, isTagalog, userPetsContext),
            listOf(
                "British Arachnological Society (BAS) Care Standards",
                "Association of Reptilian and Amphibian Veterinarians (ARAV)",
                "World Spider Catalog & Scorpion Toxicon References"
            )
        )
    }

    private fun callGeminiApi(
        apiKey: String,
        userPrompt: String,
        isTagalog: Boolean,
        petsContext: String
    ): String {
        val systemInstruction = """
You are KAPETZ AI, the premier exotic pet care assistant specializing in:
1. Tarantulas (Theraphosidae)
2. Scorpions (Scorpiones)
3. Centipedes (Chilopoda)
4. Reptiles (Squamata)

CORE MANDATES:
- ACCURACY & SAFETY: Never invent husbandry parameters. Distinguish verified knowledge from general advice.
- DO NOT recommend unnecessary handling of arachnids, centipedes, or venomous species.
- ALWAYS emphasize escape prevention (proper latches, micro-ventilation, height safety).
- VETERINARY DISCLAIMER: Clearly state that you are an AI assistant and NOT a licensed exotic animal veterinarian when addressing illnesses, dehydration curls, impaction, or injuries.
- Respond in ${if (isTagalog) "Tagalog/Filipino" else "English"}.
- Context of user's registered pets: $petsContext
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", userPrompt))
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", systemInstruction))
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.4)
                put("maxOutputTokens", 1200)
            })
        }

        val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("API error: ${response.code}")
            }
            val bodyString = response.body?.string() ?: ""
            val jsonResponse = JSONObject(bodyString)
            val candidates = jsonResponse.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text", "") ?: ""
            return text
        }
    }

    private fun extractReferences(text: String): List<String> {
        val list = mutableListOf<String>()
        if (text.contains("BAS") || text.contains("Arachnological")) {
            list.add("British Arachnological Society (BAS)")
        }
        if (text.contains("ARAV") || text.contains("Veterinarian") || text.contains("Beterinaryo")) {
            list.add("Association of Reptilian and Amphibian Veterinarians (ARAV)")
        }
        if (text.contains("CITES")) {
            list.add("Convention on International Trade in Endangered Species (CITES)")
        }
        if (list.isEmpty()) {
            list.add("Verified KAPETZ Care Guidelines (BAS & ARAV Standards)")
        }
        return list
    }

    private fun generateExpertFallbackAnswer(
        prompt: String,
        isTagalog: Boolean,
        petsContext: String
    ): String {
        val p = prompt.lowercase()

        if (p.contains("molt") || p.contains("balat") || p.contains("luno") || p.contains("shed")) {
            return if (isTagalog) {
                """
### ⚠️ Gabay sa Pagbabalat (Molting / Shedding)

1. **Huwag Galawin ang Hayop:** Kapag ang tarantula ay nakatihaya (nakabaligtad), ito ay natural na proseso ng pagbabalat. Huwag subukang itama o hawakan!
2. **Huwag Magpakain:** Huwag mag-iwan ng buhay na cricket o insekto sa loob habang nagbabalat—maaari nitong kagatin at patayin ang mahinang tarantula o alakdan.
3. **Pahinga Matapos Magbalat:** Maghintay ng 7 hanggang 10 araw bago mag-alok ng pagkain para maging matigas at itim ang pangil (chelicerae).
4. **Halumigmig:** Tiyaking may sapat na moisture at may malinis na tubig upang hindi maipit sa lumang balat.

*Paalala Medikal: Ang AI ay hindi kapalit ng propesyonal na payo mula sa isang lisensyadong exotic animal veterinarian.*
                """.trimIndent()
            } else {
                """
### ⚠️ Molting & Shedding Protocol

1. **Do NOT Disturb or Flip:** If your tarantula is lying on its back, it is in active ecdysis (molting). NEVER attempt to flip it upright or move it.
2. **Remove All Live Feeders:** Live crickets or roaches will chew on the soft exoskeleton and can cause fatal hemorrhaging.
3. **Post-Molt Hardening Time:** Wait 7 to 10 days before offering food so fangs can fully sclerotize (turn jet black). Feeding too early will break the fangs.
4. **Moisture:** Ensure adequate hydration in the water bowl and gentle humidity gradient to prevent stuck molts.

*Veterinary Warning: If the animal is trapped in a bad molt (dysdyseis), contact a qualified exotic veterinarian immediately.*
                """.trimIndent()
            }
        }

        if (p.contains("feed") || p.contains("kain") || p.contains("cricket") || p.contains("roach") || p.contains("diet")) {
            return if (isTagalog) {
                """
### 🦗 Gabay sa Pagpapakain (Feeding Guidelines)

- **Sukat ng Pagkain:** Ang laki ng insekto ay hindi dapat lumagpas sa laki ng katawan ng alaga (abdomen).
- **Iskedyul:**
  - *Slings / Scorplings:* 2 beses sa isang linggo.
  - *Juveniles:* 1 beses kada linggo.
  - *Adults:* Minsan kada 10 hanggang 14 araw.
- **Gut-loading:** Pakainin ang mga feeder insects ng sariwang gulay at oats bago ipakain sa alaga para sa mas mataas na nutrisyon.
- **Tira:** Alisin ang hindi nakain o tira (bolus) sa loob ng 24 oras upang maiwasan ang amag at mites.
                """.trimIndent()
            } else {
                """
### 🦗 Proper Feeding & Nutrition Guidelines

- **Prey Sizing:** Prey item length should not exceed the length of the tarantula's/scorpion's abdomen or carapace width.
- **Schedule:**
  - *Spiderlings / Scorplings:* Feed every 3 to 4 days.
  - *Juveniles:* Once per week.
  - *Adults:* 1 to 2 prey items every 10 to 14 days.
- **Gut-Loading:** Offer fresh carrots, squash, and grains to feeders (dubia, crickets) 24 hours prior to feeding.
- **Remove Uneaten Prey:** Pull out unconsumed insects within 24 hours to prevent stress or fungal issues.
                """.trimIndent()
            }
        }

        if (p.contains("sting") || p.contains("kagat") || p.contains("venom") || p.contains("tibo") || p.contains("bite")) {
            return if (isTagalog) {
                """
### 🚨 PROTOKOL SA PAGKAKAKAGAT O PAGKAPASO NG KAMANDAG

1. **Manatiling Kalmado:** Huwag mag-panic upang hindi bumilis ang tibok ng puso at sirkulasyon ng kamandag.
2. **Ligtas na Ilagay ang Alaga:** Gamitin ang mahabang sipit (tongs) para ibalik ang alaga sa kanyang kulungan upang maiwasan ang pangalawang kagat.
3. **Hugasan ang Sugat:** Hugasan ng malinis na tubig at banayad na sabon.
4. **Cold Compress:** Maglagay ng malamig na bimpo sa bahagi ng kagat upang mabawasan ang pamamaga. Huwag lagyan ng yelo nang direkta.
5. **PUMUNTA SA OSPITAL:** Kung ang kagat ay mula sa medikal na makamandag na uri (Centipede, Old World Tarantula, o Deathstalker), o kung may hirap sa paghinga, pamamanhid, o palpitations, pumunta agad sa pinakamalapit na Emergency Room.

*Babala: Huwag subukang sumipsip ng kamandag o gumamit ng tourniquet.*
                """.trimIndent()
            } else {
                """
### 🚨 EMERGENCY ENVENOMATION PROTOCOL

1. **Secure the Animal:** Immediately use long tongs to secure the specimen back into its latching enclosure to prevent secondary envenomation.
2. **Remain Calm:** Tachycardia accelerates venom distribution. Sit down and rest the affected limb below heart level.
3. **Wash Site:** Cleanse the wound thoroughly with antibacterial soap and warm water.
4. **Pain Management:** Apply a cool compress to mitigate localized swelling. Do NOT apply tourniquets or attempt venom extraction suction devices.
5. **SEEK EMERGENCY MEDICAL ATTENTION:** If stung/bitten by a medically significant taxon (e.g., *Scolopendra*, Old World Theraphosidae, Buthidae), or if experiencing dizziness, respiratory difficulty, chest pain, or radiating numbness, contact local Poison Control / Emergency Services immediately.

*Disclaimer: KAPETZ AI provides informational assistance only. This does not replace hospital or veterinary emergency care.*
                """.trimIndent()
            }
        }

        if (p.contains("humidity") || p.contains("temp") || p.contains("init") || p.contains("basa") || p.contains("tubig")) {
            return if (isTagalog) {
                """
### 🌡️ Temperatura at Halumigmig (Environmental Parameters)

- **Tropikal (hal. Asian Forest Scorpion, Crested Gecko):**
  - Temp: 24°C - 28°C
  - Humidity: 75% - 85%
  - Gamitin ang mamasa-masang coco peat at may malinis na lalagyan ng tubig.
- **Arid / Tuyot (hal. Mexican Redknee, GBB):**
  - Temp: 24°C - 28°C
  - Humidity: 45% - 60%
  - Tuyo ang lupa; maglaan ng mababaw na lalagyan ng tubig. Huwag labis na magwisik.
- **Cross-Ventilation:** Napakahalaga ng tamang daloy ng hangin upang maiwasan ang amag at bacteria.
                """.trimIndent()
            } else {
                """
### 🌡️ Temperature & Humidity Control

- **Tropical Species (e.g., Asian Forest Scorpion, Crested Gecko):**
  - Temp: 24°C - 28°C (75°F - 82°F)
  - Humidity: 75% - 85%
  - Utilize deep moisture-retentive substrates (coco peat/ABG mix) and maintain cross-ventilation.
- **Arid Species (e.g., Mexican Redknee, GBB):**
  - Temp: 24°C - 28°C (75°F - 82°F)
  - Humidity: 45% - 55%
  - Substrate must remain bone-dry; water dish provides sufficient drinking hydration.
- **Thermostats:** Always use proportional or on/off thermostats for any artificial heating elements.
                """.trimIndent()
            }
        }

        // Default comprehensive exotic care advice
        return if (isTagalog) {
            """
### 🦎 KAPETZ AI Exotic Care Advisory

Kumusta! Narito ang pangunahing paalala para sa iyong mga alaga ($petsContext):

1. **Ligtas na Kulungan:** Siguraduhing may matibay na kandado ang takip upang maiwasan ang pagtakas.
2. **Walang Paghawak:** Ang mga tarantula, alakdan, at alupihan ay panonood lamang (display animals) at madaling ma-stress o mapahamak kapag hinahawakan sa kamay.
3. **Suriin ang Tubig:** Siguraduhing may malinis at mababaw na lalagyan ng tubig araw-araw.
4. **Alamin ang Uri:** Bawat uri ay may natatanging pangangailangan sa init at halumigmig.

Maaari kang magtanong tungkol sa partikular na uri, pagpapakain, pagbabalat, o kulungan!

*Paalala Medikal: Kung may kakaibang sintomas tulad ng death curl o pagkawala ng gana, kumonsulta sa isang kwalipikadong exotic veterinarian.*
            """.trimIndent()
        } else {
            """
### 🦎 KAPETZ AI Exotic Care Advisory

Welcome! Here are essential husbandry principles for your exotic pets ($petsContext):

1. **Escape Prevention:** Use purpose-built terrariums with mechanical latching lids and escape-proof ventilation.
2. **Display Over Handling:** Invertebrates and venomous species are observational captives. Unnecessary handling elevates stress, drop risks, and defensive strikes.
3. **Water & Hydration:** Maintain a shallow, clean water dish. Avoid using porous sponges which harbor lethal bacteria.
4. **Species Specificity:** Avoid generalized care; respect the exact microclimate requirements of each species.

Feel free to ask specific questions regarding feeding, molting, enclosure setups, or species comparisons!

*Veterinary Notice: If you suspect injury, bacterial infection, or abnormal behavior, seek advice from a licensed exotic animal veterinarian.*
            """.trimIndent()
        }
    }
}
