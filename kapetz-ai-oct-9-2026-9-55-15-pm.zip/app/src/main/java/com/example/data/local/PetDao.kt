package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.UserPet
import com.example.model.UserProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface PetDao {
    @Query("SELECT * FROM user_pets ORDER BY id DESC")
    fun getAllPets(): Flow<List<UserPet>>

    @Query("SELECT * FROM user_pets WHERE id = :id")
    suspend fun getPetById(id: Long): UserPet?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPet(pet: UserPet): Long

    @Update
    suspend fun updatePet(pet: UserPet)

    @Delete
    suspend fun deletePet(pet: UserPet)
}

@Dao
interface ProfileDao {
    @Query("SELECT * FROM user_profiles WHERE id = 'primary_user' LIMIT 1")
    fun getProfile(): Flow<UserProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: UserProfile)
}
