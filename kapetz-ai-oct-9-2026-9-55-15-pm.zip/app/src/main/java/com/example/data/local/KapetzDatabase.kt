package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.UserPet
import com.example.model.UserProfile

@Database(
    entities = [UserPet::class, UserProfile::class],
    version = 1,
    exportSchema = false
)
abstract class KapetzDatabase : RoomDatabase() {

    abstract fun petDao(): PetDao
    abstract fun profileDao(): ProfileDao

    companion object {
        @Volatile
        private var INSTANCE: KapetzDatabase? = null

        fun getDatabase(context: Context): KapetzDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KapetzDatabase::class.java,
                    "kapetz_exotic_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
