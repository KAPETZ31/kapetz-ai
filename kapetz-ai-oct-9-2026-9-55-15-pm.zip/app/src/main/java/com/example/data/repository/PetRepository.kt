package com.example.data.repository

import com.example.data.SpeciesDatabase
import com.example.data.local.PetDao
import com.example.data.local.ProfileDao
import com.example.model.CareReminder
import com.example.model.ReminderUrgency
import com.example.model.UserPet
import com.example.model.UserProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.concurrent.TimeUnit

class PetRepository(
    private val petDao: PetDao,
    private val profileDao: ProfileDao
) {
    val allPets: Flow<List<UserPet>> = petDao.getAllPets()
    val userProfile: Flow<UserProfile?> = profileDao.getProfile()

    suspend fun addPet(pet: UserPet): Long = petDao.insertPet(pet)

    suspend fun updatePet(pet: UserPet) = petDao.updatePet(pet)

    suspend fun deletePet(pet: UserPet) = petDao.deletePet(pet)

    suspend fun saveProfile(profile: UserProfile) = profileDao.saveProfile(profile)

    suspend fun logFeeding(pet: UserPet) {
        val updated = pet.copy(
            lastFedDateMillis = System.currentTimeMillis(),
            isPostMoltResting = false
        )
        petDao.updatePet(updated)
    }

    suspend fun logMolting(pet: UserPet) {
        val updated = pet.copy(
            lastMoltDateMillis = System.currentTimeMillis(),
            isPostMoltResting = true
        )
        petDao.updatePet(updated)
    }

    // Generates real-time personalized reminders tailored to species husbandry & recorded data
    val personalizedReminders: Flow<List<CareReminder>> = petDao.getAllPets().map { pets ->
        val reminders = mutableListOf<CareReminder>()
        val now = System.currentTimeMillis()

        for (pet in pets) {
            val species = SpeciesDatabase.getById(pet.speciesId)
            val speciesName = species?.commonName ?: pet.customSpeciesName.ifEmpty { pet.category }

            // 1. Post-molt rest reminder (CRITICAL: Do not feed soft fangs/exoskeleton!)
            if (pet.isPostMoltResting && pet.lastMoltDateMillis > 0) {
                val daysSinceMolt = TimeUnit.MILLISECONDS.toDays(now - pet.lastMoltDateMillis)
                val requiredRestDays = if (pet.category == "TARANTULAS" || pet.category == "SCORPIONS") 7 else 4
                if (daysSinceMolt < requiredRestDays) {
                    val remaining = requiredRestDays - daysSinceMolt
                    reminders.add(
                        CareReminder(
                            id = "molt_rest_${pet.id}",
                            petId = pet.id,
                            petName = pet.name,
                            speciesName = speciesName,
                            title = "Post-Molt Recovery: Do Not Feed!",
                            titleTl = "Kakatapos Magbalat: Huwag Pakainin!",
                            description = "${pet.name} molted $daysSinceMolt day(s) ago. Fangs and exoskeleton are soft. Feeding now risks fatal fang breakage! Wait $remaining more day(s).",
                            descriptionTl = "Nagbalat si ${pet.name} $daysSinceMolt araw na ang nakalilipas. Malambot pa ang pangil. Mapuputol ang pangil kapag pinakain agad! Maghintay pa ng $remaining araw.",
                            urgency = ReminderUrgency.CRITICAL,
                            isDue = true,
                            dueText = "Resting: $remaining days left",
                            dueTextTl = "Nagpapalakas: $remaining araw pa"
                        )
                    )
                }
            }

            // 2. Feeding reminder
            val daysSinceFeed = TimeUnit.MILLISECONDS.toDays(now - pet.lastFedDateMillis)
            val interval = if (pet.feedIntervalDays > 0) pet.feedIntervalDays else 7

            if (daysSinceFeed >= interval) {
                val overdueDays = daysSinceFeed - interval
                val dueStr = if (overdueDays > 0) "Overdue by $overdueDays day(s)" else "Due today"
                val dueStrTl = if (overdueDays > 0) "Lampas na ng $overdueDays araw" else "Dapat pakainin ngayon"
                reminders.add(
                    CareReminder(
                        id = "feed_${pet.id}",
                        petId = pet.id,
                        petName = pet.name,
                        speciesName = speciesName,
                        title = "Feeding Scheduled",
                        titleTl = "Oras ng Pagpapakain",
                        description = "Last fed $daysSinceFeed days ago. Check water bowl and offer size-appropriate prey.",
                        descriptionTl = "Huling napakain $daysSinceFeed araw na ang nakalipas. Suriin ang tubig at maghanda ng angkop na pagkain.",
                        urgency = if (overdueDays >= 3) ReminderUrgency.CRITICAL else ReminderUrgency.UPCOMING,
                        isDue = true,
                        dueText = dueStr,
                        dueTextTl = dueStrTl
                    )
                )
            }

            // 3. Species-specific environmental reminders
            if (species?.id == "scorpion_afs" || species?.id == "centipede_vietnamese") {
                reminders.add(
                    CareReminder(
                        id = "humidity_${pet.id}",
                        petId = pet.id,
                        petName = pet.name,
                        speciesName = speciesName,
                        title = "Moisture & Hydration Check",
                        titleTl = "Suriin ang Halumigmig at Tubig",
                        description = "${species.commonName} requires 75-85% humidity. Check substrate moisture gradient and refill water dish.",
                        descriptionTl = "Kailangan ng 75-85% humidity. Suriin kung mamasa-masa ang lupa at punuin ang lalagyan ng tubig.",
                        urgency = ReminderUrgency.INFO,
                        isDue = false,
                        dueText = "Routine check",
                        dueTextTl = "Karaniwang pagsusuri"
                    )
                )
            } else if (species?.id == "reptile_crested_gecko") {
                reminders.add(
                    CareReminder(
                        id = "temp_${pet.id}",
                        petId = pet.id,
                        petName = pet.name,
                        speciesName = speciesName,
                        title = "Temperature Safety Vigilance",
                        titleTl = "Bantayan ang Temperatura",
                        description = "Ensure ambient temperature stays below 27°C (80°F) to avoid dangerous heat stress for New Caledonian geckos.",
                        descriptionTl = "Tiyaking hindi lalampas sa 27°C ang init upang hindi ma-heat stroke ang gecko.",
                        urgency = ReminderUrgency.INFO,
                        isDue = false,
                        dueText = "Climate alert",
                        dueTextTl = "Babala sa klima"
                    )
                )
            }
        }
        reminders
    }
}
