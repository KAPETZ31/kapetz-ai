package com.example.data

import com.example.model.Species
import com.example.model.SpeciesCategory
import com.example.model.Temperament
import com.example.model.VenomLevel

object SpeciesDatabase {

    val allSpecies: List<Species> = listOf(
        // ================= TARANTULAS =================
        Species(
            id = "tarantula_redknee",
            commonName = "Mexican Redknee Tarantula",
            commonNameTl = "Mexican Redknee Tarantula",
            scientificName = "Brachypelma hamorii",
            category = SpeciesCategory.TARANTULAS,
            naturalHabitat = "Pacific coastal slopes and dry thorn forests of Mexico (Colima, Michoacán, Guerrero).",
            naturalHabitatTl = "Tuyot na kagubatan at gilid ng bundok sa baybayin ng Pasipiko sa Mexico.",
            adultSize = "14 - 16 cm (5.5 - 6.5 in) diagonal leg span",
            lifespan = "Females: 20 - 30+ years | Males: 5 - 8 years",
            lifespanTl = "Babae: 20 - 30+ taon | Lalaki: 5 - 8 taon",
            enclosure = "Terrestrial setup. Minimum 30x30x30 cm. Crucial: Height should not exceed 1.5x leg span above substrate to prevent fatal falls.",
            enclosureTl = "Lupang kulungan (Terrestrial). Huwag masyadong mataas upang hindi mapahamak kapag nahulog ang tarantula.",
            substrate = "10 - 15 cm deep coco fiber or peat moss/topsoil mix, packed down firmly for burrowing.",
            substrateTl = "10 - 15 cm kapal ng coco peat o pinaghalong lupa para makapaghukay.",
            ventilation = "Moderate cross-ventilation. Avoid excessive draft but prevent stagnant moisture pockets.",
            ventilationTl = "Katamtamang bentilasyon (cross-ventilation) upang hindi magkaroon ng amag.",
            temperatureRange = "24°C - 28°C (75°F - 82°F)",
            humidityRange = "55% - 65% (Dry substrate with an overflowing shallow water dish)",
            hydration = "Shallow, clean water dish. Do not use sponges (bacterial risk). Overflow slightly once a month.",
            hydrationTl = "Mababaw na lalagyan ng malinis na tubig. Huwag gumamit ng espongha.",
            diet = "Gut-loaded crickets, dubia roaches, red runner roaches, occasional hornworms.",
            dietTl = "Crickets, dubia roaches, red runners na pinakain ng masustansya.",
            feedingSchedule = "Slings: 2x/week (pinhead crickets) | Juveniles: 1x/week | Adults: 1-2 prey items every 10-14 days.",
            feedingScheduleTl = "Maliit (Sling): 2 beses kada linggo | Matanda: 1-2 insekto kada 10-14 araw.",
            behavior = "New World terrestrial. Generally calm but will kick urticating setae (hairs) from abdomen if stressed.",
            behaviorTl = "Kalmado ngunit nagtatapon ng makating balahibo (urticating hairs) sa puwitan kapag nagulat.",
            moltingInfo = "Will flip on back. NEVER disturb or flip upright during molting. Wait 7-10 days for fangs to turn jet black before feeding.",
            moltingInfoTl = "Hihiga nang patihaya kapag magbabalat. Huwag gagalawin! Maghintay ng 7-10 araw bago magpakain.",
            breedingNotes = "CITES Appendix II listed. Ensure female is well-fed prior to introducing mature male.",
            breedingNotesTl = "Protektado ng CITES. Tiyaking busog ang babae bago ipasok ang lalaki.",
            commonMistakes = listOf(
                "Keeping substrate too wet, which induces stress and death curls",
                "Excessive enclosure height leading to fatal abdominal rupture falls",
                "Offering live prey immediately post-molt before fangs harden",
                "Unnecessary physical handling causing accidental drops"
            ),
            commonMistakesTl = listOf(
                "Masyadong basang lupa na nagdudulot ng pagkakasakit",
                "Mataas na kulungan na sanhi ng pagkahulog at pagputok ng tiyan",
                "Pagpapakain agad matapos magbalat habang malambot pa ang pangil",
                "Paghawak sa kamay na maaaring maging sanhi ng pagkahulog"
            ),
            sources = listOf(
                "British Arachnological Society (BAS) Guidelines",
                "World Spider Catalog (WSC 2024)",
                "Schultz, S. & Schultz, M. (The Tarantula Keeper's Guide, 3rd Ed.)"
            ),
            isVerified = true,
            warningNotes = "Urticating hairs cause intense itching, skin dermatitis, and severe corneal damage if rubbed into eyes.",
            warningNotesTl = "Ang balahibo nito ay lubhang makati at delikado kapag napunta sa mata.",
            venomLevel = VenomLevel.MILD,
            temperament = Temperament.DOCILE,
            handlingRecommended = false
        ),
        Species(
            id = "tarantula_gbb",
            commonName = "Greenbottle Blue Tarantula",
            commonNameTl = "Greenbottle Blue Tarantula (GBB)",
            scientificName = "Chromatopelma cyaneopubescens",
            category = SpeciesCategory.TARANTULAS,
            naturalHabitat = "Paraguaná Peninsula, Venezuela. Arid scrubland and coastal desert dunes.",
            naturalHabitatTl = "Tuyong kagubatan at buhanginan sa Paraguaná Peninsula, Venezuela.",
            adultSize = "13 - 15 cm (5 - 6 in) diagonal leg span",
            lifespan = "Females: 12 - 14 years | Males: 3 - 4 years",
            lifespanTl = "Babae: 12 - 14 taon | Lalaki: 3 - 4 taon",
            enclosure = "Semi-arboreal / Terrestrial heavy webber. Provide multiple anchor points (cork bark, fake plants) for heavy webbing.",
            enclosureTl = "Mahilig maghabi ng makakapal na sapot. Lagyan ng sanga at cork bark bilang kapitan ng sapot.",
            substrate = "Dry coco fiber mixed with sand/soil, 5 - 8 cm. Keep completely dry.",
            substrateTl = "Tuyo na coco fiber at buhangin. Huwag babasain ang lupa.",
            ventilation = "High cross-ventilation is mandatory. Stagnant humid air is lethal to this arid species.",
            ventilationTl = "Mataas na bentilasyon. Ang kulob at basang hangin ay nakamamatay sa uring ito.",
            temperatureRange = "24°C - 28°C (75°F - 82°F)",
            humidityRange = "40% - 50% (Arid condition)",
            hydration = "Glued/secured water dish on substrate; lightly mist a corner of webbing once every 2 weeks for drinking droplets.",
            hydrationTl = "Maliit na lalagyan ng tubig; wisikan ang gilid ng sapot paminsan-minsan para makainom.",
            diet = "Roaches (Dubia/Red runners), crickets, locusts. Known for exceptional feeding response.",
            dietTl = "Roaches at crickets. Mabilis at masiglang kumain.",
            feedingSchedule = "Juveniles: 1x every 5-7 days | Adults: 1-2 medium roaches every 10-14 days.",
            feedingScheduleTl = "Matanda: 1-2 katamtamang insekto kada 10-14 araw.",
            behavior = "Fast, skittish, and elaborate structural webber. Rarely burrows; prefers sitting on web castles.",
            behaviorTl = "Mabilis tumakbo at gumagawa ng kamangha-manghang sapot sa ibabaw.",
            moltingInfo = "Molts directly inside its elaborate web tube hammock. Do not disturb the hammock structure.",
            moltingInfoTl = "Nagluluno sa loob ng kanyang hinabing sapot. Huwag sirain ang sapot.",
            breedingNotes = "Females can be aggressive towards males. Introduce male carefully with an escape route.",
            breedingNotesTl = "Maaaring maging agresibo ang babae sa lalaki. Maglaan ng ligtas na daan palabas.",
            commonMistakes = listOf(
                "Misting the enclosure frequently and creating humid stagnant conditions",
                "Not providing sufficient anchor points for webbing",
                "Panicking due to high sprint speed during rehousing"
            ),
            commonMistakesTl = listOf(
                "Madalas na pagwisik na nagpapasobra sa moisture",
                "Kakulangan sa mga sanga para pagkabitan ng sapot",
                "Pagkataranta kapag mabilis na tumakbo habang inililipat"
            ),
            sources = listOf(
                "Journal of the British Tarantula Society",
                "Peters, H.-J. Tarantulas of the World"
            ),
            isVerified = true,
            warningNotes = "Extremely fast sprinter with potent urticating hairs. Will readily bolt if startled.",
            warningNotesTl = "Napakabilis tumakbo at nagtatapon ng makating balahibo. Huwag hawakan sa kamay.",
            venomLevel = VenomLevel.MILD,
            temperament = Temperament.NERVOUS,
            handlingRecommended = false
        ),
        Species(
            id = "tarantula_obt",
            commonName = "Orange Baboon Tarantula (OBT)",
            commonNameTl = "Orange Baboon Tarantula (OBT)",
            scientificName = "Pterinochilus murinus",
            category = SpeciesCategory.TARANTULAS,
            naturalHabitat = "Eastern and Southern Africa (Kenya, Tanzania, Mozambique, Zimbabwe).",
            naturalHabitatTl = "Silangang at Timog Aprika (Kenya, Tanzania).",
            adultSize = "11 - 13 cm (4.5 - 5 in) leg span",
            lifespan = "Females: 12 - 15 years | Males: 3 - 4 years",
            lifespanTl = "Babae: 12 - 15 taon | Lalaki: 3 - 4 taon",
            enclosure = "Opportunistic fossorial/semi-arboreal. Heavy webber. Needs secure latching lid and deep substrate.",
            enclosureTl = "Mabilis at mabangis. Nangangailangan ng matibay na takip at malalim na lupa.",
            substrate = "Dry substrate 10 - 15 cm deep. Will web extensively.",
            substrateTl = "Tuyong lupa na 10 - 15 cm ang lalim.",
            ventilation = "Ample dry cross-ventilation.",
            ventilationTl = "Magandang daloy ng hangin.",
            temperatureRange = "25°C - 29°C (77°F - 84°F)",
            humidityRange = "45% - 55% (Dry)",
            hydration = "Water dish provided on ground level.",
            hydrationTl = "Lalagyan ng tubig sa ibaba.",
            diet = "Crickets, roaches. Voracious appetite.",
            dietTl = "Crickets at roaches.",
            feedingSchedule = "Adults: 1x every 10-12 days.",
            feedingScheduleTl = "Matanda: 1 beses kada 10-12 araw.",
            behavior = "Old World species: DOES NOT have urticating hairs. Highly defensive, lightning-fast threat pose and defensive strike.",
            behaviorTl = "Walang makating balahibo ngunit napakabilis umatake at mag-threat pose.",
            moltingInfo = "Molts inside deep webbed burrow.",
            moltingInfoTl = "Nagluluno sa loob ng lungga.",
            breedingNotes = "High risk of male cannibalism. Advanced keepers only.",
            breedingNotesTl = "Mataas ang tsansa na makain ang lalaki. Para sa mga sanay na mag-alaga lamang.",
            commonMistakes = listOf(
                "Attempting to handle (EXTREMELY DANGEROUS)",
                "Underestimating strike speed and telemetry",
                "Using top-opening enclosures where tarantula webs the lid"
            ),
            commonMistakesTl = listOf(
                "Pagtatangkang hawakan (LUBHANG DELIKADO)",
                "Maliit na pagtantiya sa bilis ng kagat",
                "Paggamit ng kulungan na sa itaas bumubukas kung saan nakakabit ang sapot"
            ),
            sources = listOf("African Arachnological Society", "Bocxlaer, B. et al. Phylogenetics of African Theraphosidae"),
            isVerified = true,
            warningNotes = "HOT SPECIES: Severe venom potency. Bites cause extreme radiating pain, muscle cramping, nausea, and tachycardia.",
            warningNotesTl = "BABALA: Medically significant ang kamandag. Ang kagat ay nagdudulot ng matinding pananakit at pamumulikat.",
            venomLevel = VenomLevel.MEDICALLY_SIGNIFICANT,
            temperament = Temperament.AGGRESSIVE_STRIKER,
            handlingRecommended = false
        ),

        // ================= SCORPIONS =================
        Species(
            id = "scorpion_afs",
            commonName = "Asian Forest Scorpion",
            commonNameTl = "Asian Forest Scorpion (AFS)",
            scientificName = "Heterometrus silenus",
            category = SpeciesCategory.SCORPIONS,
            naturalHabitat = "Tropical rainforests of Southeast Asia (Vietnam, Cambodia, Laos, Thailand).",
            naturalHabitatTl = "Tropikal na kagubatan ng Timog-Silangang Asya (Vietnam, Thailand, Laos).",
            adultSize = "12 - 16 cm (5 - 6.5 in) length",
            lifespan = "7 - 10 years",
            lifespanTl = "7 - 10 taon",
            enclosure = "Minimum 5-10 gallon glass or acrylic terrarium. Flat cork bark hide and moss.",
            enclosureTl = "5-10 galon na terrarium na may taguan gawa sa cork bark at lumot.",
            substrate = "10 - 12 cm deep coconut fiber, peat moss, or tropical bioactive soil to retain moisture.",
            substrateTl = "10 - 12 cm kapal ng coco peat upang mapanatili ang tamang halumigmig (humidity).",
            ventilation = "Moderate ventilation. Must retain humidity without mold outbreaks.",
            ventilationTl = "Katamtamang bentilasyon upang manatiling mamasa-masa nang walang amag.",
            temperatureRange = "24°C - 29°C (75°F - 84°F). Heat mat on side wall with thermostat if ambient is low.",
            humidityRange = "75% - 85% (Consistently moist, never waterlogged)",
            hydration = "Heavy, shallow ceramic water dish. Mist substrate daily or every 2 days.",
            hydrationTl = "Mababaw ngunit mabigat na lalagyan ng tubig. Wisikan ang paligid 1 beses kada 1-2 araw.",
            diet = "Gut-loaded dubia roaches, crickets, mealworms, lateral roaches.",
            dietTl = "Dubia roaches, crickets, mealworms.",
            feedingSchedule = "Scorplings: 2x/week | Adults: 1-2 prey items once a week.",
            feedingScheduleTl = "Scorplings: 2 beses kada linggo | Matanda: 1 beses kada linggo.",
            behavior = "Nocturnal ambush predator. Primarily relies on powerful chelae (pincers) rather than sting. Fluoresces bright cyan under UV blacklight.",
            behaviorTl = "Gising sa gabi; mas ginagamit ang malalaking sipit kaysa sa tibo. Umiilaw na kulay asul sa UV blacklight.",
            moltingInfo = "Scorpions molt standing up or slightly elevated. Requires high humidity (80%+) to prevent fatal stuck exuviae.",
            moltingInfoTl = "Nangangailangan ng 80%+ na humidity habang nagluluno upang hindi maipit sa lumang balat.",
            breedingNotes = "Ovoviviparous (gives live birth). Mother carries scorplings on her back until their 1st molt.",
            breedingNotesTl = "Nanganganak nang buhay. Dinadala ng ina ang mga anak sa kanyang likod hanggang sa unang pagbabalat.",
            commonMistakes = listOf(
                "Letting substrate dry out completely (causes dehydration and molt failure)",
                "Placing heat pads beneath the floor (scorpions burrow to escape heat, risking burns)",
                "Cohabitation without abundant hides, risking cannibalism during molts"
            ),
            commonMistakesTl = listOf(
                "Pabayaang matuyo ang lupa (sanhi ng dehydration at pagpalya ng pagbalat)",
                "Paglalagay ng pampainit sa ilalim ng lupa (naglulungga ang alakdan para lumamig)",
                "Pagsasama-sama nang walang sapat na taguan na nagiging sanhi ng pagkain sa kapwa"
            ),
            sources = listOf(
                "Kovařík, F. (2020). Review of Heterometrus (Scorpiones: Scorpionidae)",
                "Prendini, L. Systematics of Scorpion Families"
            ),
            isVerified = true,
            warningNotes = "Mild venom comparable to a wasp sting, but pincers can pinch with significant pressure. Handling is not recommended.",
            warningNotesTl = "Mababang kamandag na katumbas ng kagat ng bubuyog, ngunit napakalakas ng sipit. Huwag hawakan sa kamay.",
            venomLevel = VenomLevel.MILD,
            temperament = Temperament.DOCILE,
            handlingRecommended = false
        ),
        Species(
            id = "scorpion_emperor",
            commonName = "Emperor Scorpion",
            commonNameTl = "Emperor Scorpion",
            scientificName = "Pandinus imperator",
            category = SpeciesCategory.SCORPIONS,
            naturalHabitat = "Rainforests and savannas of West Africa (Ghana, Ivory Coast, Nigeria, Togo).",
            naturalHabitatTl = "Kagubatan at savanna ng Kanlurang Aprika (Ghana, Ivory Coast).",
            adultSize = "18 - 20 cm (7 - 8 in) length",
            lifespan = "6 - 8+ years",
            lifespanTl = "6 - 8+ taon",
            enclosure = "10+ gallon terrarium. Abundant flat rocks, cork bark, and deep burrowing zones.",
            enclosureTl = "10+ galon na terrarium na may malalaking taguan.",
            substrate = "12 - 15 cm deep organic soil, cypress mulch, or coco coir mix.",
            substrateTl = "12 - 15 cm kapal ng organic soil at coco coir.",
            ventilation = "Moderate cross-ventilation.",
            ventilationTl = "Katamtamang bentilasyon.",
            temperatureRange = "26°C - 30°C (78°F - 86°F)",
            humidityRange = "75% - 85%",
            hydration = "Clean, sturdy water bowl at all times.",
            hydrationTl = "Palaging may malinis na tubig sa mangkok.",
            diet = "Roaches, crickets, superworms.",
            dietTl = "Roaches, crickets, superworms.",
            feedingSchedule = "Adults: 1-2 insects once a week or every 10 days.",
            feedingScheduleTl = "Matanda: 1-2 insekto minsan kada 7-10 araw.",
            behavior = "Calm, large, docile. Massive granulose claws. Rarely uses stinger unless heavily provoked.",
            behaviorTl = "Napakalaki, maamo, at bihirang gumamit ng tibo.",
            moltingInfo = "Maintain strict 85% humidity during molt window.",
            moltingInfoTl = "Panatilihin ang 85% humidity kapag magbabalat.",
            breedingNotes = "CITES Appendix II protected due to heavy pet-trade collection in native range.",
            breedingNotesTl = "Protektado ng CITES Appendix II.",
            commonMistakes = listOf(
                "Purchasing wild-caught specimens without checking captive-bred provenance",
                "Allowing temperature to drop below 22°C (causes lethargy and digestive stagnation)",
                "Confusing with Asian Forest Scorpions (Emperor has bumpy granulated claws, AFS has smooth claws)"
            ),
            commonMistakesTl = listOf(
                "Pagbili ng galing sa gubat kaysa sa captive-bred",
                "Pagbaba ng temperatura sa ilalim ng 22°C",
                "Pagkalito sa pagitan ng Emperor at Asian Forest (mabutil ang sipit ng Emperor, makinis ang sa AFS)"
            ),
            sources = listOf("CITES Species Database", "Lourenço, W. R. Scorpions of the World"),
            isVerified = true,
            warningNotes = "Sting has low medical significance, but strict CITES compliance and escape prevention are required.",
            warningNotesTl = "Mababang kamandag ngunit kinakailangan ang pagsunod sa batas at ligtas na kulungan.",
            venomLevel = VenomLevel.MILD,
            temperament = Temperament.DOCILE,
            handlingRecommended = false
        ),
        Species(
            id = "scorpion_deathstalker",
            commonName = "Deathstalker Scorpion",
            commonNameTl = "Deathstalker Scorpion",
            scientificName = "Leiurus quinquestriatus",
            category = SpeciesCategory.SCORPIONS,
            naturalHabitat = "Deserts and scrublands of North Africa and the Middle East.",
            naturalHabitatTl = "Disyerto ng Hilagang Aprika at Gitnang Silangan.",
            adultSize = "8 - 10 cm (3 - 4 in)",
            lifespan = "4 - 6 years",
            lifespanTl = "4 - 6 taon",
            enclosure = "Escape-proof acrylic or glass with airtight silicone seals and locking latch. Sand substrate.",
            enclosureTl = "Napakaselyadong kulungan na may kandado. Huwag hayaang makatakas kailanman.",
            substrate = "Dry desert sand and clay mix, 5 - 8 cm.",
            substrateTl = "Tuyong buhangin at luwad.",
            ventilation = "Dry cross-ventilation.",
            ventilationTl = "Tuyong bentilasyon.",
            temperatureRange = "28°C - 34°C (82°F - 93°F)",
            humidityRange = "20% - 35% (Extremely dry)",
            hydration = "Small water dish overflowed once every 2-3 weeks only.",
            hydrationTl = "Kaunting tubig lamang kada 2-3 linggo.",
            diet = "Small crickets and roaches.",
            dietTl = "Maliliit na crickets at roaches.",
            feedingSchedule = "Adults: 1 small prey item every 10 days.",
            feedingScheduleTl = "Matanda: 1 maliit na insekto kada 10 araw.",
            behavior = "Nervous, lightning-fast defensive stings. High agility.",
            behaviorTl = "Napakabilis magtibo kapag naistorbo.",
            moltingInfo = "Ensure moderate warmth during molt.",
            moltingInfoTl = "Mainit-init na lugar habang nagluluno.",
            breedingNotes = "Extreme hazard during pairing. Professional venom researchers only.",
            breedingNotesTl = "Lubhang mapanganib sa pagpaparami. Para lamang sa mga lisensyadong mananaliksik.",
            commonMistakes = listOf(
                "Allowing inexperienced keepers to maintain this species",
                "Using tongs shorter than 30 cm (12 in)",
                "Lack of secondary containment lockbox"
            ),
            commonMistakesTl = listOf(
                "Pag-aalaga ng baguhan (BAWAL)",
                "Paggamit ng maikling sipit sa halip na mahabang 30cm tongs",
                "Walang pangalawang kahon na may kandado (secondary containment)"
            ),
            sources = listOf("World Health Organization (WHO) Guidelines on Scorpion Stings", "Bavestrello et al. Toxicon"),
            isVerified = true,
            warningNotes = "HAZARDOUS VENOM: Potent neurotoxin (chlorotoxin, charybdotoxin). Sting causes pulmonary edema, cardiac arrhythmias, excruciating pain, and can be fatal to humans.",
            warningNotesTl = "BABALA SA BUHAY: May matinding neurotoxin. Ang tibo ay maaaring nakamamatay sa tao. Nangangailangan ng agarang ospital.",
            venomLevel = VenomLevel.HAZARDOUS,
            temperament = Temperament.DEFENSIVE,
            handlingRecommended = false
        ),

        // ================= CENTIPEDES =================
        Species(
            id = "centipede_vietnamese",
            commonName = "Vietnamese Giant Centipede",
            commonNameTl = "Vietnamese Giant Centipede",
            scientificName = "Scolopendra dehaani",
            category = SpeciesCategory.CENTIPEDES,
            naturalHabitat = "Tropical rainforests and damp leaf litter across Southeast Asia.",
            naturalHabitatTl = "Tropikal na gubat at basang dahon sa Timog-Silangang Asya.",
            adultSize = "18 - 25 cm (7 - 10 in)",
            lifespan = "6 - 10 years",
            lifespanTl = "6 - 10 taon",
            enclosure = "HEAVY SECURE LOCKING ENCLOSURE. Centipedes can push through tiny crevices and lift loose lids. Enclosure height must exceed the centipede's full body length.",
            enclosureTl = "MAHIGPIT NA MAY KANDADO. Kayang sumiksik sa napakaliit na butas at buhatin ang takip.",
            substrate = "12 - 15 cm deep moist coco coir, sphagnum moss, and organic forest leaf litter.",
            substrateTl = "12 - 15 cm basang coco peat, lumot, at tuyong dahon.",
            ventilation = "Micro-drilled cross-ventilation holes (smaller than 2mm) to prevent escape.",
            ventilationTl = "Napakaliit na butas ng bentilasyon (mas maliit sa 2mm) upang hindi makatakas.",
            temperatureRange = "24°C - 28°C (75°F - 82°F)",
            humidityRange = "70% - 85% (Must remain humid; prone to rapid desiccation)",
            hydration = "Heavy ceramic water bowl; keep one half of substrate damp at all times.",
            hydrationTl = "Mabigat na mangkok ng tubig; laging basain ang kalahati ng lupa.",
            diet = "Roaches, large crickets, occasional thawed pinky mouse for breeding adults.",
            dietTl = "Roaches, crickets, paminsan-minsang pinky mouse.",
            feedingSchedule = "Juveniles: 1x/week | Adults: 1x every 10-14 days.",
            feedingScheduleTl = "Matanda: 1 beses kada 10-14 araw.",
            behavior = "Aggressive, light-sensitive, subterranean hunter. Will strike instantly if touched. Possesses modified toxic front legs (forcipules).",
            behaviorTl = "Napakabilis at agresibo. May makamandag na forcipules (pangil sa unahan).",
            moltingInfo = "Burrows deep into moist substrate for molts. Will consume its exuvia after shedding for nutrients.",
            moltingInfoTl = "Naglulungga nang malalim kapag magbabalat at kinakain ang lumang balat.",
            breedingNotes = "Female coils around egg mass for up to 2 months without eating. Extreme stress causes egg consumption.",
            breedingNotesTl = "Pumupulupot ang ina sa mga itlog. Kapag naabala ay kakainin ang sariling itlog.",
            commonMistakes = listOf(
                "Loose lid clips allowing escape (they possess remarkable muscular leverage)",
                "Ventilation holes larger than their head width",
                "Allowing substrate to dry out (leads to fatal dehydration within 48 hours)"
            ),
            commonMistakesTl = listOf(
                "Maluwag na takip na nagiging sanhi ng pagtakas",
                "Masyadong malalaking butas ng bentilasyon",
                "Pagkatuyo ng lupa na ikamamatay sa loob ng 48 oras"
            ),
            sources = listOf("Kronmüller, C. (Review of Scolopendridae)", "Undheim, E. et al. Centipede Venom Proteomics"),
            isVerified = true,
            warningNotes = "HIGH MEDICAL SIGNIFICANCE: Forcipule envenomation causes agonizing pain, severe swelling, tissue necrosis, fever, and anaphylaxis risk. NEVER HANDLE.",
            warningNotesTl = "BABALA: Ang kagat ay nagdudulot ng matinding kirot, pamamaga, at necrosis sa balat. HUWAG HAWAKAN.",
            venomLevel = VenomLevel.MEDICALLY_SIGNIFICANT,
            temperament = Temperament.AGGRESSIVE_STRIKER,
            handlingRecommended = false
        ),

        // ================= REPTILES =================
        Species(
            id = "reptile_crested_gecko",
            commonName = "Crested Gecko",
            commonNameTl = "Crested Gecko",
            scientificName = "Correlophus ciliatus",
            category = SpeciesCategory.REPTILES,
            naturalHabitat = "Rainforest canopies of New Caledonia (South Province and Isle of Pines).",
            naturalHabitatTl = "Kaitaasan ng mga puno sa New Caledonia.",
            adultSize = "20 - 25 cm (8 - 10 in) total length",
            lifespan = "15 - 20 years",
            lifespanTl = "15 - 20 taon",
            enclosure = "Vertical arboreal terrarium (minimum 45x45x60 cm / 18x18x24 in). Abundant vines, cork branches, and broad foliage for 70% canopy cover.",
            enclosureTl = "Mataas na kulungan (Arboreal). Lagyan ng maraming halaman, sanga, at baging.",
            substrate = "Bioactive tropical soil, ABG mix, or coconut fiber with leaf litter layer.",
            substrateTl = "Lupa para sa bioactive o coco peat na may tuyong dahon.",
            ventilation = "Screen top with side vents to allow humidity dry-out cycles.",
            ventilationTl = "Bentilasyon sa itaas at gilid para matuyo ang basang hangin sa araw.",
            temperatureRange = "22°C - 26°C (72°F - 78°F). CRITICAL: Temperatures above 29°C (85°F) cause fatal heat stroke.",
            humidityRange = "50% - 60% daytime dry-out, spiking to 80% - 90% during nightly misting.",
            hydration = "Elevated magnetic water dish. Drinks water droplets licked from leaves after misting.",
            hydrationTl = "Umiinom ng patak ng tubig sa mga dahon matapos wisikan sa gabi.",
            diet = "Complete crested gecko diet powder (CGD like Pangea or Repashy). Gut-loaded calcium-dusted insects 1-2x weekly.",
            dietTl = "Crested gecko diet paste (Pangea/Repashy) at crickets na may calcium powder.",
            feedingSchedule = "Juveniles: fresh CGD every other day | Adults: fresh CGD 3x/week.",
            feedingScheduleTl = "Sariwang crested gecko paste 3 beses kada linggo.",
            behavior = "Nocturnal, docile arboreal climber. Prehensile tail and adhesive toe lamellae. Note: If dropped, tail does not regenerate.",
            behaviorTl = "Gising sa gabi, maamo. Tandaan: Kapag naputol ang buntot ay hindi na ito tutubo muli.",
            moltingInfo = "Sheds skin every 2-4 weeks and eats it immediately. Requires evening misting to avoid stuck toe shed.",
            moltingInfoTl = "Nagluluno at kinakain ang balat. Wisikan upang hindi magka-ipit na balat sa mga daliri.",
            breedingNotes = "Female needs ample calcium reserves to prevent egg-binding and metabolic bone disease.",
            breedingNotesTl = "Kailangan ng sapat na calcium ang babae upang hindi magkaroon ng MBD o maipit ang itlog.",
            commonMistakes = listOf(
                "Exposing gecko to heat lamps above 28°C causing fatal overheating",
                "Feeding only insects without complete vitamin/mineral gecko diet",
                "Keeping humidity saturated at 90% 24/7 without a dry-out cycle (causes lung infections)"
            ),
            commonMistakesTl = listOf(
                "Masyadong mainit na ilaw na nagdudulot ng heat stroke",
                "Insekto lang ang pinapakain nang walang kumpletong gecko diet powder",
                "Babad na basang kulungan buong araw nang walang dry-out cycle (sanhi ng impeksyon sa baga)"
            ),
            sources = listOf("Association of Reptilian and Amphibian Veterinarians (ARAV)", "Rhacodactylus Husbandry Journal"),
            isVerified = true,
            warningNotes = "Non-venomous. Very sensitive to high temperatures. Always provide cool spots below 26°C.",
            warningNotesTl = "Walang kamandag. Mabilis mamatay sa sobrang init (huwag lalampas sa 28°C).",
            venomLevel = VenomLevel.MILD,
            temperament = Temperament.DOCILE,
            handlingRecommended = true
        ),
        Species(
            id = "reptile_leopard_gecko",
            commonName = "Leopard Gecko",
            commonNameTl = "Leopard Gecko",
            scientificName = "Eublepharis macularius",
            category = SpeciesCategory.REPTILES,
            naturalHabitat = "Rocky, dry grasslands and clay deserts of Afghanistan, Pakistan, and Northwest India.",
            naturalHabitatTl = "Mabatong tuyong kapatagan at disyerto ng Afghanistan at Pakistan.",
            adultSize = "18 - 25 cm (7 - 10 in)",
            lifespan = "15 - 20+ years",
            lifespanTl = "15 - 20+ taon",
            enclosure = "Terrestrial (minimum 60x45x30 cm). Minimum 3 distinct hides: Warm hide, Cool hide, and Moist shedding hide.",
            enclosureTl = "Lupang kulungan na may 3 taguan: Mainit, Malamig, at Mamasa-masang taguan para sa pagbalat.",
            substrate = "Slate tile, paper towels, or packed excavator clay/sand-soil mix. NEVER use loose calcium sand (impaction risk).",
            substrateTl = "Tile, paper towel, o pinatigas na clay mix. BAWAL ang maluwag na calcium sand dahil nakakabara sa tiyan.",
            ventilation = "Screen top with open ventilation.",
            ventilationTl = "Maluwang na bentilasyon.",
            temperatureRange = "Basking/Warm spot: 31°C - 33°C (88°F - 92°F) | Cool side: 22°C - 24°C (72°F - 75°F).",
            humidityRange = "30% - 40% ambient, with 70% - 80% inside the dedicated moist hide.",
            hydration = "Shallow bowl of fresh water. Clean dish of pure calcium powder without D3 in enclosure.",
            hydrationTl = "Mababaw na tubig at platito ng purong calcium powder na walang D3 sa loob.",
            diet = "Exclusively insectivorous: crickets, mealworms, dubia roaches dusted with calcium and vitamins.",
            dietTl = "Mga insekto lamang na binudburan ng calcium at bitamina.",
            feedingSchedule = "Juveniles: daily | Adults: 4-6 gut-loaded insects every 2-3 days.",
            feedingScheduleTl = "Matanda: 4-6 na insekto kada 2-3 araw.",
            behavior = "Crepuscular, calm ground-dweller. True eyelids (can blink) and stores fat in thick tail.",
            behaviorTl = "Gising tuwing takipsilim, may talukap sa mata, at nag-iimbak ng taba sa buntot.",
            moltingInfo = "Uses moist hide with damp sphagnum moss to peel shed. Check toes regularly for stuck skin.",
            moltingInfoTl = "Pumapasok sa basang taguan para magbalat. Bantayan ang mga daliri.",
            breedingNotes = "Temperature-dependent sex determination (TSD).",
            breedingNotesTl = "Ang temperatura ng itlog ang nagtatakda ng kasarian.",
            commonMistakes = listOf(
                "Using heat rocks (causes severe third-degree belly burns)",
                "Using pure loose silica/calcium sand causing fatal gastrointestinal impaction",
                "Neglecting vitamin A and calcium supplementation resulting in Metabolic Bone Disease (MBD)"
            ),
            commonMistakesTl = listOf(
                "Paggamit ng heat rock (nakakapaso sa tiyan)",
                "Paggamit ng buhangin na nakakabara sa bituka kapag nakain",
                "Kakulangan sa calcium na nagdudulot ng Metabolic Bone Disease (MBD / pagbaluktot ng buto)"
            ),
            sources = listOf("Association of Reptilian and Amphibian Veterinarians (ARAV)", "de Vosjoli, P. The Leopard Gecko Manual"),
            isVerified = true,
            warningNotes = "Non-venomous. Docile reptile companion, but tail can drop under stress and takes energy to regrow.",
            warningNotesTl = "Walang kamandag. Maamo ngunit pwedeng maputol ang buntot kapag hinawakan nang marahas.",
            venomLevel = VenomLevel.MILD,
            temperament = Temperament.DOCILE,
            handlingRecommended = true
        )
    )

    fun getById(id: String): Species? = allSpecies.find { it.id == id }

    fun getByCategory(category: SpeciesCategory): List<Species> =
        allSpecies.filter { it.category == category }

    fun search(query: String): List<Species> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return allSpecies
        return allSpecies.filter {
            it.commonName.lowercase().contains(q) ||
            it.commonNameTl.lowercase().contains(q) ||
            it.scientificName.lowercase().contains(q) ||
            it.category.name.lowercase().contains(q) ||
            it.naturalHabitat.lowercase().contains(q)
        }
    }
}
