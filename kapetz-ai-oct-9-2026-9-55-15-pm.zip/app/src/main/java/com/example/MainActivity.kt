package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.SpeciesDatabase
import com.example.ui.components.KapetzBottomNavigationBar
import com.example.ui.components.KapetzTopBar
import com.example.ui.screens.*
import com.example.ui.theme.KapetzTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.KapetzViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KapetzTheme {
                KapetzApp()
            }
        }
    }
}

@Composable
fun KapetzApp(
    viewModel: KapetzViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val isTagalog by viewModel.isTagalog.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val userPets by viewModel.userPets.collectAsStateWithLifecycle()
    val careReminders by viewModel.careReminders.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val checklist by viewModel.checklist.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val isChatLoading by viewModel.isChatLoading.collectAsStateWithLifecycle()
    val compare1 by viewModel.compareSpecies1.collectAsStateWithLifecycle()
    val compare2 by viewModel.compareSpecies2.collectAsStateWithLifecycle()

    // Handle back button on sub-screens
    BackHandler(enabled = currentScreen != AppScreen.Home) {
        when (currentScreen) {
            is AppScreen.SpeciesDetail -> viewModel.navigateTo(AppScreen.Library)
            else -> viewModel.navigateTo(AppScreen.Home)
        }
    }

    val onBackAction: (() -> Unit)? = if (currentScreen != AppScreen.Home) {
        {
            when (currentScreen) {
                is AppScreen.SpeciesDetail -> viewModel.navigateTo(AppScreen.Library)
                else -> viewModel.navigateTo(AppScreen.Home)
            }
        }
    } else null

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            KapetzTopBar(
                currentScreen = currentScreen,
                isTagalog = isTagalog,
                onToggleLanguage = { viewModel.toggleLanguage() },
                onNavigateProfile = { viewModel.navigateTo(AppScreen.Profile) },
                onBack = onBackAction
            )
        },
        bottomBar = {
            KapetzBottomNavigationBar(
                currentScreen = currentScreen,
                isTagalog = isTagalog,
                onNavigate = { viewModel.navigateTo(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
                when (screen) {
                    is AppScreen.Home -> {
                        HomeScreen(
                            isTagalog = isTagalog,
                            reminders = careReminders,
                            onNavigate = { viewModel.navigateTo(it) },
                            onSelectCategory = { cat ->
                                viewModel.selectCategory(cat)
                            }
                        )
                    }

                    is AppScreen.Library -> {
                        SpeciesLibraryScreen(
                            isTagalog = isTagalog,
                            speciesList = viewModel.getFilteredSpeciesList(),
                            searchQuery = searchQuery,
                            selectedCategory = selectedCategory,
                            onSearchChange = { viewModel.setSearchQuery(it) },
                            onCategorySelect = { viewModel.selectCategory(it) },
                            onSpeciesClick = { id ->
                                viewModel.navigateTo(AppScreen.SpeciesDetail(id))
                            }
                        )
                    }

                    is AppScreen.SpeciesDetail -> {
                        val species = SpeciesDatabase.getById(screen.speciesId)
                            ?: SpeciesDatabase.allSpecies.first()
                        SpeciesDetailScreen(
                            species = species,
                            isTagalog = isTagalog,
                            onBack = { viewModel.navigateTo(AppScreen.Library) },
                            onAskAboutSpecies = { prompt ->
                                viewModel.navigateTo(AppScreen.AiChat)
                                viewModel.sendChatMessage(prompt)
                            }
                        )
                    }

                    is AppScreen.Compare -> {
                        SpeciesCompareScreen(
                            isTagalog = isTagalog,
                            species1 = compare1,
                            species2 = compare2,
                            onSelectSpecies1 = { viewModel.setCompareSpecies1(it) },
                            onSelectSpecies2 = { viewModel.setCompareSpecies2(it) }
                        )
                    }

                    is AppScreen.MyPets -> {
                        MyPetsScreen(
                            isTagalog = isTagalog,
                            pets = userPets,
                            reminders = careReminders,
                            onAddPet = { name, speciesId, customSpecies, category, acqDate, stage, feedInterval, notes ->
                                viewModel.addPet(name, speciesId, customSpecies, category, acqDate, stage, feedInterval, notes)
                            },
                            onDeletePet = { viewModel.deletePet(it) },
                            onLogFeeding = { viewModel.logFeeding(it) },
                            onLogMolting = { viewModel.logMolting(it) }
                        )
                    }

                    is AppScreen.SetupGuides -> {
                        SetupGuidesScreen(isTagalog = isTagalog)
                    }

                    is AppScreen.Checklist -> {
                        ChecklistScreen(
                            isTagalog = isTagalog,
                            checklist = checklist,
                            onToggleItem = { viewModel.toggleChecklistItem(it) },
                            onResetChecklist = { viewModel.resetChecklist() }
                        )
                    }

                    is AppScreen.AiChat -> {
                        AiChatScreen(
                            isTagalog = isTagalog,
                            messages = chatMessages,
                            isLoading = isChatLoading,
                            onSendMessage = { viewModel.sendChatMessage(it) }
                        )
                    }

                    is AppScreen.Profile -> {
                        ProfileScreen(
                            isTagalog = isTagalog,
                            profile = userProfile,
                            onSaveProfile = { u, e, exp, r ->
                                viewModel.saveProfile(u, e, exp, r)
                            },
                            onToggleLanguage = { viewModel.toggleLanguage() }
                        )
                    }
                }
            }
        }
    }
}
